/* جنة القرآن v8 — المصحف بالصفحات: صورة مصحف المدينة، نص قابل للنقر، تلوين التجويد، تنقّل بالسحب، علامات صفحات */
'use strict';
const PG_SURAH=[1,2,50,77,106,128,151,177,187,208,221,235,249,255,262,267,282,293,305,312,322,332,342,350,359,367,377,385,396,404,411,415,418,428,434,440,446,453,458,467,477,483,489,496,499,502,507,511,515,518,520,523,526,528,531,534,537,542,545,549,551,553,554,556,558,560,562,564,566,568,570,572,574,575,577,578,580,582,583,585,586,587,587,589,590,591,591,592,593,594,595,595,596,596,597,597,598,598,599,599,600,600,601,601,601,602,602,602,603,603,603,604,604,604];
const PG_JUZ=Array.from({length:30},(_,i)=>i?2+20*i:1).map((p,i)=>i==0?1:20*i+2);
const pgSurah=p=>{let s=1;for(let i=0;i<114;i++)if(PG_SURAH[i]<=p)s=i+1;return s};
const juzOf=p=>p<=21?1:Math.min(30,Math.floor((p-2)/20)+1);
const PG_IMG=n=>`https://raw.githubusercontent.com/GovarJabbar/Quran-PNG/master/${pad(n)}.png`;
/* ألوان أحكام التجويد (رموز alquran.cloud) */
const TJ={h:['همزة وصل','#9aa0a6'],s:['حرف لا يُنطق','#9aa0a6'],l:['لام شمسية','#9aa0a6'],n:['مدّ طبيعي (٢)','#e8892b'],p:['مدّ جائز (٢-٤-٦)','#e8892b'],m:['مدّ لازم (٦)','#d6322e'],o:['مدّ واجب (٤-٥)','#d6551e'],q:['قلقلة','#2f7fd1'],c:['إخفاء شفوي','#7a4cc2'],f:['إخفاء','#7a4cc2'],w:['إدغام شفوي','#1a9a63'],i:['إقلاب','#c2427f'],a:['إدغام بغنّة','#1a9a63'],u:['إدغام بلا غنّة','#6aa84f'],d:['إدغام متجانسين','#6aa84f'],b:['إدغام متقاربين','#6aa84f'],g:['غنّة (٢)','#14a3a3']};
function tjHtml(t){let o='',last=0;t.replace(/\[([a-z])(?::\d+)?\[([^\]]*)\]/g,(m,c,x,i)=>{o+=esc(t.slice(last,i))+(TJ[c]?`<span class="tj" style="color:${TJ[c][1]}">${esc(x)}</span>`:esc(x));last=i+m.length;return m});return o+esc(t.slice(last))}
/* صفحة من الذاكرة المحلية إن كان القرآن محمّلًا كاملًا (تعمل دون إنترنت) */
async function pageLocal(n){if(!ls.get('qdl'))return null;const px=await dbGet('a:pidx');if(!px||!px[n-1]||!px[n-1].length)return null;await names();const ays=[];
  for(const [s,a1,a2] of px[n-1]){const d=await api('/surah/'+s+'/quran-uthmani');for(let a=a1;a<=a2;a++){const y=d.ayahs[a-1];if(y)ays.push(Object.assign({},y,{surah:{number:s,name:d.name,englishName:d.englishName}}))}}
  return ays.length?{number:n,ayahs:ays}:null}
async function pgData(n,ed){if(ed=='quran-uthmani'){try{const L=await pageLocal(n);if(L)return L}catch(e){dbg(e,'pageLocal')}}return api('/page/'+n+'/'+ed)}
function pgHtml(d,tj){let h='';d.ayahs.forEach(y=>{const s=y.surah.number,a=y.numberInSurah;
  if(a==1)h+=`<div class="sbn">سورة ${esc(nm(s))}</div>`+(s!=1&&s!=9?`<div class="bsm">${BSM}</div>`:'');
  const t=clean(s,a,y.text);h+=`<span class="ay" onclick="sheet(${s},${a})">${tj?tjHtml(t):esc(t)} <i class="n">﴿${AR(a)}﴾</i></span> `});return h}
async function pgText(n,tj,note){const b=$('#pgb');if(!b)return;b.innerHTML=LD;
  try{await names();let d;
    try{d=await pgData(n,tj?'quran-tajweed':'quran-uthmani')}catch(e){if(!tj)throw e;d=await pgData(n,'quran-uthmani');tj=false;note='تعذّر تحميل ألوان التجويد، عُرض النص العادي'}
    if($('#pgb')&&ls.get('pg')==n){const y=d.ayahs[0],s=y.surah.number;$('#pgb').innerHTML=(note?`<div class="sub">${esc(note)}</div>`:'')+`<div class="qt pgt">${pgHtml(d,tj)}</div>`;
      const i=$('#pgi');if(i)i.textContent='سورة '+nm(s)+' · الجزء '+AR(y.juz||juzOf(n))+' · صفحة '+AR(n)+' / '+AR(604)}}
  catch(e){dbg(e,'pgText');b.innerHTML='<div class="mt">⚠️ تعذّر تحميل الصفحة، تأكد من الإنترنت.<br><button class="b" style="margin-top:10px" onclick="mushaf(ls.get(\'pg\',1))">إعادة المحاولة</button></div>'}}
function pgImg(n){const b=$('#pgb');if(!b)return;b.innerHTML=`<img id="pimg" class="pimg" alt="صفحة ${AR(n)}" src="${PG_IMG(n)}" onerror="pgText(${n},false,'تعذّر تحميل صورة الصفحة، عُرض النص بدلًا منها')">`;
  const i=$('#pgi');if(i)i.textContent='سورة '+(S.names?nm(pgSurah(n)):'')+' · الجزء '+AR(juzOf(n))+' · صفحة '+AR(n)+' / '+AR(604)}
function mushaf(n){n=Math.max(1,Math.min(604,+n||1));ls.set('pg',n);S.tab='more';S.inReader=false;clearInterval(S.iv);try{stopCmp()}catch(e){dbg(e)}
  const mode=ls.get('pgm','img'),bm=ls.get('pgbm',[]).includes(n);
  v.innerHTML=`<div class="row mhd"><button class="o" onclick="mushaf(${n-1})" ${n<=1?'disabled':''}>→ السابقة</button><input class="in" type="number" min="1" max="604" value="${n}" onchange="mushaf(this.value)" aria-label="رقم الصفحة"><button class="o" onclick="mushaf(${n+1})" ${n>=604?'disabled':''}>التالية ←</button></div>
  <div class="seg" id="pgm">${[['img','🖼 مصحف'],['txt','📖 نص'],['tj','🎨 تجويد']].map(x=>`<button data-m="${x[0]}" class="${mode==x[0]?'on':''}">${x[1]}</button>`).join('')}</div>
  <div class="sub" id="pgi"></div><div id="pgb" class="pgb"></div>
  <div class="row"><button class="o" onclick="pgGo()">🔎 اذهب إلى…</button><button class="o" id="pgbmb">${bm?'🔖 محفوظة':'🔖 علامة'}</button>${mode=='tj'?'<button class="o" onclick="pgLegend()">🎨 الألوان</button>':''}</div>
  <button class="o w" onclick="go('more')">→ رجوع</button>`;
  document.querySelectorAll('#pgm button').forEach(b=>b.onclick=()=>{ls.set('pgm',b.dataset.m);mushaf(n)});
  $('#pgbmb').onclick=()=>{const L=ls.get('pgbm',[]),i=L.indexOf(n);i<0?L.push(n):L.splice(i,1);ls.set('pgbm',L.sort((a,b)=>a-b));mushaf(n)};
  const b=$('#pgb');let x0=null;b.ontouchstart=e=>{x0=e.touches[0].clientX};
  b.ontouchend=e=>{if(x0==null)return;const dx=e.changedTouches[0].clientX-x0;x0=null;if(Math.abs(dx)>70)mushaf(n+(dx>0?1:-1))};
  if(mode=='img')pgImg(n);else pgText(n,mode=='tj');
  scrollTo(0,0)}
function pgGo(){const L=ls.get('pgbm',[]);openSheet(`<h3>🔎 اذهب إلى</h3><label class="lb">سورة</label><select class="w" id="pgs"><option value="">—</option>${PG_SURAH.map((p,i)=>`<option value="${p}">${AR(i+1)}. ${S.names?esc(nm(i+1)):''}</option>`).join('')}</select>
  <label class="lb">جزء</label><select class="w" id="pgj"><option value="">—</option>${Array.from({length:30},(_,i)=>`<option value="${i?20*i+2:1}">الجزء ${AR(i+1)}</option>`).join('')}</select>
  ${L.length?`<label class="lb">علاماتي</label><div class="chips" style="flex-wrap:wrap">${L.map(p=>`<span class="chip" onclick="closeSheet();mushaf(${p})">${AR(p)}</span>`).join('')}</div>`:''}`);
  ['pgs','pgj'].forEach(id=>$('#'+id).onchange=e=>{if(e.target.value){closeSheet();mushaf(+e.target.value)}})}
function pgLegend(){openSheet(`<h3>🎨 ألوان أحكام التجويد</h3>${Object.keys(TJ).map(k=>`<div class="sr"><span class="tj" style="color:${TJ[k][1]};font:700 22px Amiri">●</span><div class="f1 t" style="color:var(--ik)">${TJ[k][0]}</div></div>`).join('')}`)}
/* تحميل ورد مسبقًا للقراءة بدون إنترنت (نص + تجويد + صور الصفحات) */
async function pgPrefetch(a,b){a=Math.max(1,+a||1);b=Math.min(604,+b||a);if(pgPrefetch.busy)return toast('التحميل جارٍ…');pgPrefetch.busy=1;let ok=0;
  try{toast('جارٍ تحميل الصفحات '+AR(a)+' – '+AR(b)+'…');await names();const c=await caches.open('jq-pages');
    for(let p=a;p<=b;p++){try{await pgData(p,'quran-uthmani');try{await pgData(p,'quran-tajweed')}catch(e){dbg(e,'tj prefetch')}
      try{const u=PG_IMG(p);if(!(await c.match(u))){const r=await fetch(u,{mode:'cors'});if(r.ok)await c.put(u,r)}}catch(e){dbg(e,'img prefetch')}ok++}catch(e){dbg(e,'prefetch '+p)}}
    toast(ok==b-a+1?'تم التحميل ✅ الصفحات متاحة دون إنترنت':'حُمّلت '+AR(ok)+' من '+AR(b-a+1)+' صفحة')}
  catch(e){dbg(e,'pgPrefetch');toast('تعذّر التحميل')}finally{pgPrefetch.busy=0}}
