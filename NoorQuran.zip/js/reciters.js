/* جنة القرآن v8 — محرّك القرّاء: اسم واحد لكل قارئ، تجميع الروايات والأساليب، الأشهر أولًا، بحث وتصفية
   REC (مسطّح للتوافق): [0 معرّف، 1 الاسم الكامل، 2 مسار mp3quran، 3 مجلد everyayah، 4 قائمة السور أو null،
                         5 الرواية، 6 الأسلوب، 7 اسم القارئ، 8 مفتاح القارئ، 9 كل المعرّفات المدمجة، 10 معرّف CDN] */
'use strict';
const CDN_IDS=new Set(REC.slice(0,13).map(r=>r[0]).filter(x=>x.startsWith('ar.')));
/* everyayah: [المعرّف، الاسم، المجلد، الأسلوب، الرواية] */
const EA=[
['ea.basit_m','عبد الباسط عبد الصمد','Abdul_Basit_Mujawwad_128kbps','مجوّد'],
['ea.basit_t','عبد الباسط عبد الصمد','Abdul_Basit_Murattal_192kbps'],
['ea.basfar','عبد الله بصفر','Abdullah_Basfar_192kbps'],
['ea.budair','صلاح البدير','Salah_Al_Budair_128kbps'],
['ea.qatami','ناصر القطامي','Nasser_Alqatami_128kbps'],
['ea.qahtani','خالد القحطاني','Khaalid_Abdullaah_al-Qahtaanee_192kbps'],
['ea.rifai','هاني الرفاعي','Hani_Rifai_192kbps'],
['ea.ghamdi','سعد الغامدي','Ghamadi_40kbps'],
['ea.qasim','محسن القاسم','Muhsin_Al_Qasim_192kbps'],
['ea.tablawi','محمد الطبلاوي','Mohammad_al_Tablaway_128kbps'],
['ea.husary_m','محمود خليل الحصري','Husary_Mujawwad_128kbps','مجوّد'],
['ea.husary_t','محمود خليل الحصري','Husary_Muallim_128kbps','معلّم'],
['ea.minsh_m','محمد صديق المنشاوي','Minshawy_Mujawwad_192kbps','مجوّد'],
['ea.akhdar','إبراهيم الأخضر','Ibrahim_Akhdar_32kbps'],
['ea.bukhatir','صلاح بو خاطر','Salaah_AbdulRahman_Bukhatir_128kbps'],
['ea.juhany','عبد الله عوّاد الجهني','Abdullaah_3awwaad_Al-Juhaynee_128kbps'],
['ea.mustafa','مصطفى إسماعيل','Mustafa_Ismail_48kbps'],
['ea.jaber','علي جابر','Ali_Jaber_64kbps'],
['ea.fares','فارس عبّاد','Fares_Abbad_64kbps'],
['ea.ayman','أيمن سويد','Ayman_Sowaid_64kbps'],
['ea.matroud','عبد الله المطرود','Abdullah_Matroud_128kbps'],
['ea.neana','أحمد نعينع','Ahmed_Neana_128kbps'],
['ea.alaqimy','أكرم العلاقمي','Akram_AlAlaqimy_128kbps'],
['ea.sahl','سهل ياسين','Sahl_Yassin_128kbps'],
['ea.salamah','ياسر سلامة','Yaser_Salamah_128kbps'],
['ea.tunaiji','خليفة الطنيجي','Khalefa_Al_Tunaiji_64kbps'],
['ea.suesy','علي الحجّاج السويسي','Ali_Hajjaj_AlSuesy_128kbps'],
['ea.mansoori','كريم منصوري','Karim_Mansoori_40kbps'],
['ea.nabil','نبيل الرفاعي','Nabil_Rifa3i_48kbps'],
['ea.abkar','إدريس أبكر','Idrees_Abkar_128kbps'],
['ea.alafasy','مشاري العفاسي','Alafasy_128kbps'],
['ea.sudais','عبد الرحمن السديس','Abdurrahmaan_As-Sudais_192kbps'],
['ea.shuraim','سعود الشريم','Saood_ash-Shuraym_128kbps'],
['ea.maher','ماهر المعيقلي','Maher_AlMuaiqly_128kbps'],
['ea.hudhaify','علي الحذيفي','Hudhaify_128kbps'],
['ea.ajamy','أحمد العجمي','Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaballah.net'],
['ea.ayyoub','محمد أيوب','Muhammad_Ayyoub_128kbps'],
['ea.jibreel','محمد جبريل','Muhammad_Jibreel_128kbps'],
['ea.shaatree','أبو بكر الشاطري','Abu_Bakr_Ash-Shaatree_128kbps'],
['ea.minsh_t','محمد صديق المنشاوي','Minshawy_Murattal_128kbps'],
['ea.husary','محمود خليل الحصري','Husary_128kbps'],
['ea.abdulkareem','محمد عبد الكريم','Muhammad_AbdulKareem_128kbps'],
['ea.w_dosary','إبراهيم الدوسري','warsh/warsh_ibrahim_aldosary_128kbps','مرتّل','ورش'],
['ea.w_jazaery','ياسين الجزائري','warsh/warsh_yassin_al_jazaery_64kbps','مرتّل','ورش'],
['ea.w_basit','عبد الباسط عبد الصمد','warsh/warsh_Abdul_Basit_128kbps','مرتّل','ورش']];
/* الأشهر أولًا (الترتيب = الأولوية)؛ الأسماء هنا هي الاسم المعروض */
const TOP=['مشاري العفاسي','ماهر المعيقلي','عبد الرحمن السديس','سعود الشريم','ياسر الدوسري','محمد صديق المنشاوي','عبد الباسط عبد الصمد','محمود خليل الحصري','علي الحذيفي','سعد الغامدي','ناصر القطامي','أحمد العجمي','صلاح البدير','عبد الله بصفر','هاني الرفاعي','خالد الجليل','عبد المحسن القاسم','محسن القاسم','إدريس أبكر','عبد الباري الثبيتي','بندر بليلة','فارس عباد','أيمن سويد','صلاح بو خاطر','محمد أيوب','محمد جبريل','عادل الكلباني','رعد الكردي','ياسر سلامة','وديع اليمني','خالد القحطاني','إبراهيم الأخضر','محمد اللحيدان','محمد الطبلاوي','مصطفى إسماعيل','أبو بكر الشاطري','نبيل الرفاعي','عمر القزابري','ياسين الجزائري','إبراهيم الدوسري','محمد رفعت','عبد العزيز الزهراني','منصور السالمي','أحمد النفيس','سهل ياسين','علي جابر','خليفة الطنيجي','توفيق الصايغ','ناصر العصفور','عبد الله الجهني'];
const RIW=[['ورش',/ورش/],['قالون',/قالون/],['الدوري',/دوري/],['السوسي',/سوسي/],['شعبة',/شعبه/],['البزي',/بزي/],['قنبل',/قنبل/],['خلاد',/خلاد/],['هشام',/هشام/],['ابن ذكوان',/ذكوان/],['رويس',/رويس/],['روح',/(^| )روح( |$)/],['خلف',/(^| )خلف( |$)/],['حفص',/حفص/]];
const STOP=new Set(['الشيخ','الدكتور','د','القارئ','الاستاذ','استاذ','الحاج','المقرئ','الشيخه']);
/* مفتاح القارئ: الاسم الأول + الأخير بعد توحيد الإملاء، فيُدمج «مشاري راشد العفاسي» و«مشاري العفاسي» */
function RK(n){const w=norm(String(n)).split(' ').filter(x=>x&&!STOP.has(x)),o=[];
  for(let i=0;i<w.length;i++){if(w[i]=='عبد'&&i+1<w.length){o.push('عبد'+w[i+1]);i++}else o.push(w[i])}
  if(!o.length)return'';if(o.length==1)return o[0];return o[0]+'|'+o[o.length-1].replace(/^ال/,'')}
const TOPK=new Map();TOP.forEach((n,i)=>{const k=RK(n);if(!TOPK.has(k))TOPK.set(k,{i,n})});
function parseM(nm){const s=norm(nm||'');let rw='حفص';for(const x of RIW){if(x[1].test(s)){rw=x[0];break}}
  const st=/مجود/.test(s)?'مجوّد':/معلم/.test(s)?'معلّم':'مرتّل';return[rw,st]}
const vlabel=(rw,st)=>rw!='حفص'?rw+(st!='مرتّل'?' · '+st:''):st;
const VORD=['مرتّل','مجوّد','معلّم'];
let RAW=[];const RG=[];
const rawAdd=o=>RAW.push(Object.assign({mq:null,ea:null,cdn:null,list:null,rw:'حفص',st:'مرتّل',src:''},o));
function mergeV(v,o){v.ids.push(o.id);
  if(o.mq){if(!v.mq){v.mq=o.mq;v.list=o.list}else if(v.list&&!o.list){v.mq=o.mq;v.list=null}else if(v.list&&o.list&&o.list.length>v.list.length){v.mq=o.mq;v.list=o.list}}
  if(!v.ea&&o.ea)v.ea=o.ea;if(!v.cdn&&o.cdn)v.cdn=o.cdn}
function recIdx(id){return REC.findIndex(r=>r[9]&&r[9].includes(id))}
function recById(id){const i=recIdx(id);return i>=0?REC[i]:null}
function rebuildRec(){
  const r0=REC[S.rec],cur=r0?(r0[9]?r0[9].slice():[r0[0]]):[],G=new Map();
  RAW.forEach(o=>{const k=RK(o.name)||o.id;let g=G.get(k);if(!g){g={key:k,names:[],vars:new Map()};G.set(k,g)}
    g.names.push(String(o.name).replace(/^(الشيخ|الدكتور)\s+/,'').trim());
    const vk=o.rw+'|'+o.st,v=g.vars.get(vk);if(!v)g.vars.set(vk,Object.assign({},o,{ids:[o.id]}));else mergeV(v,o)});
  const gs=[...G.values()].map(g=>{const t=TOPK.get(g.key);
    const nm=t?t.n:g.names.slice().sort((a,b)=>(b.includes(' ')-a.includes(' '))||a.length-b.length)[0];
    const vs=[...g.vars.values()].sort((a,b)=>((a.rw=='حفص'?0:1)-(b.rw=='حفص'?0:1))||(VORD.indexOf(a.st)-VORD.indexOf(b.st))||a.rw.localeCompare(b.rw,'ar'));
    return{key:g.key,name:nm,rank:t?t.i:999,vs}}).sort((a,b)=>(a.rank-b.rank)||a.name.localeCompare(b.name,'ar'));
  REC.length=0;RG.length=0;
  gs.forEach(g=>{const multi=g.vs.length>1,ents=g.vs.map(v=>{const full=g.name+(multi||v.rw!='حفص'?' — '+vlabel(v.rw,v.st):'');
      const e=[v.ids[0],full,v.mq,v.ea,v.list,v.rw,v.st,g.name,g.key,v.ids,v.cdn];REC.push(e);return e});
    RG.push({key:g.key,name:g.name,rank:g.rank,vars:ents,nq:norm(g.name+' '+ents.map(e=>e[5]+' '+e[6]).join(' '))})});
  let i=-1;for(const id of cur){i=recIdx(id);if(i>=0)break}
  if(i<0){const sid=ls.get('recid');if(sid)i=recIdx(sid)}
  if(i<0)i=recIdx('ar.alafasy');
  S.rec=Math.max(0,i);
  if(REC[S.rec]&&ls.get('recid')!==REC[S.rec][0])ls.set('rec',S.rec)}
/* مصادر البداية: القرّاء الأساسيون (من index.html) + everyayah */
REC.slice(0,13).forEach(r=>rawAdd({id:r[0],name:r[1],mq:r[2]||null,ea:r[0]=='ev.yasser'?'Yasser_Ad-Dussary_128kbps':null,cdn:/^ar\./.test(r[0])?r[0]:null,src:'base'}));
EA.forEach(e=>rawAdd({id:e[0],name:e[1],ea:e[2],st:e[3]||'مرتّل',rw:e[4]||'حفص',src:'ea'}));
rebuildRec();
/* قرّاء mp3quran: القائمة الكاملة تُجلب وتُخزَّن أسبوعًا في IndexedDB */
const MQK='mq:v8';
function mergeMq(list){RAW=RAW.filter(o=>o.src!='mq');
  list.forEach(x=>{const[rw,st]=parseM(x[3]);rawAdd({id:'mq.'+x[0],name:x[1],mq:x[2],list:x[4],rw,st,src:'mq'})});rebuildRec();return list.length}
async function loadMq(){let c=await dbGet(MQK);if(c&&c.l)mergeMq(c.l);if(c&&Date.now()-c.t<6048e5)return;
  try{const j=await getJ('https://mp3quran.net/api/v3/reciters?language=ar',25000),out=[];
    (j.reciters||[]).forEach(rc=>(rc.moshaf||[]).forEach(m=>{const tot=+m.surah_total||0;if(!m.server||tot<1)return;
      const srv=String(m.server).replace(/^https?:\/\//,'').replace(/\/+$/,''),lst=tot>=114?null:String(m.surah_list||'').split(',').map(Number).filter(Boolean);
      out.push([m.id,rc.name,srv,m.name||'',lst])}));
    if(out.length){await dbSet(MQK,{t:Date.now(),l:out});mergeMq(out)}}catch(e){dbg(e,'loadMq')}}
loadMq();
/* ---------- نافذة اختيار القارئ ---------- */
const RP={q:'',riw:'all',fav:false,n:60,open:''};
const recFav=()=>ls.get('recfav',[]);
const recShort=()=>{const r=REC[S.rec];return r?r[7]+(r[5]!='حفص'?' · '+r[5]:''):'—'};
function recPicker(cb){window._rpcb=cb;Object.assign(RP,{q:'',riw:S.riw=='warsh'?'ورش':'all',fav:false,n:60,open:''});
  openSheet(`<h3>🎙 اختر القارئ</h3><input class="in" id="rpq" placeholder="ابحث عن قارئ… (${AR(RG.length)} قارئًا)" autocomplete="off"><div class="chips" id="rpc"></div><div id="rpl"></div>`);
  $('#rpq').oninput=e=>{RP.q=e.target.value;RP.n=60;rpDraw()};
  $('#rpl').onclick=rpClick;$('#rpc').onclick=rpClick;rpDraw()}
function rpSup(v){const a=[];a.push(v[2]?'سور كاملة':'');if(v[3]||v[10])a.push('آية بآية');if(v[4])a.push(AR(v[4].length)+' سورة فقط');return a.filter(Boolean).join(' · ')}
function rpDraw(){const q=norm(RP.q),fv=recFav(),cnt={};
  RG.forEach(g=>new Set(g.vars.map(v=>v[5])).forEach(r=>cnt[r]=(cnt[r]||0)+1));
  const riws=Object.keys(cnt).sort((a,b)=>(a=='حفص'?-1:0)-(b=='حفص'?-1:0)||(a=='ورش'?-1:0)-(b=='ورش'?-1:0)||cnt[b]-cnt[a]);
  $('#rpc').innerHTML=[['all','الكل'],['fav','⭐ المفضلة']].concat(riws.map(r=>[r,r+' ('+AR(cnt[r])+')'])).map(x=>`<span class="chip ${(x[0]=='fav'?RP.fav:(!RP.fav&&RP.riw==x[0]))?'on':''}" data-act="chip" data-k="${esc(x[0])}">${esc(x[1])}</span>`).join('');
  let L=RG.filter(g=>(!q||g.nq.includes(q))&&(RP.riw=='all'||g.vars.some(v=>v[5]==RP.riw))&&(!RP.fav||fv.includes(g.key)));
  if(!RP.fav)L=L.filter(g=>fv.includes(g.key)).concat(L.filter(g=>!fv.includes(g.key)));
  const curK=REC[S.rec]&&REC[S.rec][8];
  $('#rpl').innerHTML=L.slice(0,RP.n).map(g=>{const vs=g.vars.filter(v=>RP.riw=='all'||v[5]==RP.riw),op=RP.open==g.key&&vs.length>1;
    const sub=vs.length>1?AR(vs.length)+' روايات/أساليب · '+[...new Set(vs.map(v=>v[5]))].join('، '):vlabel(vs[0][5],vs[0][6])+' · '+rpSup(vs[0]);
    return `<div class="rg"><div class="sr" data-act="tap" data-k="${esc(g.key)}"><div class="f1"><div class="t">${esc(g.name)}</div><div class="sub" style="text-align:right">${esc(sub)}</div></div><span class="rf" data-act="fav" data-k="${esc(g.key)}" aria-label="مفضلة">${fv.includes(g.key)?'★':'☆'}</span>${g.key==curK?'✅':''}</div>`+
      (op?vs.map(v=>{const i=REC.indexOf(v);return `<button class="vr" data-act="pick" data-i="${i}"><span class="f1"><b>${esc(vlabel(v[5],v[6]))}</b><span class="sub" style="display:block;text-align:right">${esc(rpSup(v))}</span></span>${i==S.rec?'✅':''}</button>`}).join(''):'')+'</div>'}).join('')||'<p class="mt">لا نتائج</p>';
  if(L.length>RP.n)$('#rpl').insertAdjacentHTML('beforeend',`<button class="o w" data-act="more">عرض المزيد (${AR(L.length-RP.n)})</button>`)}
function rpClick(e){const el=e.target.closest('[data-act]');if(!el)return;const act=el.dataset.act,k=el.dataset.k;
  if(act=='chip'){if(k=='fav'){RP.fav=!RP.fav}else{RP.fav=false;RP.riw=k}RP.n=60;RP.open='';return rpDraw()}
  if(act=='more'){RP.n+=60;return rpDraw()}
  if(act=='fav'){e.stopPropagation();const f=recFav(),i=f.indexOf(k);i<0?f.push(k):f.splice(i,1);ls.set('recfav',f);return rpDraw()}
  if(act=='pick')return pickRec(+el.dataset.i);
  if(act=='tap'){const g=RG.find(x=>x.key==k);if(!g)return;const vs=g.vars.filter(v=>RP.riw=='all'||v[5]==RP.riw);
    if(vs.length==1)return pickRec(REC.indexOf(vs[0]));RP.open=RP.open==k?'':k;rpDraw()}}
function pickRec(i){if(!REC[i])return;S.rec=i;ls.set('rec',i);closeSheet();toast('🎙 '+REC[i][1]);
  const rr=$('#rr');if(rr)rr.value=i;document.querySelectorAll('.rrb').forEach(b=>b.textContent='🎙 '+REC[i][1]);
  if(window._rpcb)window._rpcb(i)}
