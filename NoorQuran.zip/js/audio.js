/* جنة القرآن v8 — المشغّل المتقدم (قائمة القرّاء في reciters.js) */
'use strict';
/* ---------- المشغّل ---------- */
const SPD=[0.75,1,1.25,1.5,2];S.spd=ls.get('spd',1);au.defaultPlaybackRate=S.spd;
S.rm=ls.get('rmode',0);S.an=ls.get('autonext',true);let WARNED=0,SKIPSAVE=0;
$('#player').innerHTML=`<button id="pv" onclick="pPrev()">⏮</button><button id="pp" onclick="tp()">⏸</button><button id="pn_" onclick="pNext()">⏭</button><span id="pt"></span><button id="psp" class="sp" onclick="cycSpd()"></button><button id="prm" onclick="cycRm()"></button><button onclick="recPicker()">🎙</button><button onclick="sleepT()">⏲</button><button onclick="stopP()">✕</button><div class="pr2"><small id="pc">0:00</small><input id="ps" type="range" min="0" max="1000" value="0"><small id="pd">0:00</small></div>`;
const fmt=t=>isFinite(t)?Math.floor(t/60)+':'+z2(Math.floor(t%60)):'0:00';
function uiP(){$('#psp').textContent=AR(S.spd)+'×';$('#prm').textContent=['➡️','🔂','🔁'][S.rm];$('#prm').title=['بدون تكرار','تكرار السورة/المقطع','تكرار القائمة']}
function cycSpd(){S.spd=SPD[(SPD.indexOf(S.spd)+1)%SPD.length];ls.set('spd',S.spd);au.defaultPlaybackRate=au.playbackRate=S.spd;uiP()}
function cycRm(){S.rm=(S.rm+1)%3;ls.set('rmode',S.rm);uiP();toast(['بدون تكرار','تكرار السورة الحالية','تكرار قائمة التشغيل'][S.rm])}
uiP();
au.addEventListener('loadedmetadata',()=>{au.playbackRate=S.spd;if(S._seek){au.currentTime=Math.min(S._seek,au.duration||S._seek);S._seek=0}});
au.addEventListener('timeupdate',()=>{const sl=$('#ps');if(!sl||S._drag)return;if(au.duration>0)sl.value=au.currentTime/au.duration*1000;$('#pc').textContent=fmt(au.currentTime);$('#pd').textContent=fmt(au.duration);
  if(cur&&Date.now()-SKIPSAVE>4000){SKIPSAVE=Date.now();saveRes()}});
$('#ps').oninput=()=>{S._drag=1;$('#pc').textContent=fmt($('#ps').value/1000*au.duration)};
$('#ps').onchange=()=>{if(au.duration>0)au.currentTime=$('#ps').value/1000*au.duration;S._drag=0};
function saveRes(){if(!cur)return;const r=REC[S.rec];ls.set('ares',{m:cur.m,s:cur.s,a:cur.a||0,n:cur.n||0,t:cur.m=='f'?au.currentTime:0,rid:r[0],full:!!cur.full,ts:Date.now()})}
function resumeListen(){const o=ls.get('ares');if(!o)return toast('لا يوجد استماع سابق');const i=recIdx(o.rid);if(i>=0){S.rec=i;ls.set('rec',i)}
  if(o.m=='f'){S._seek=o.t;playFull(o.s)}else{playAyah(o.s,o.a,o.n,1,o.full)}}
/* رابط الصوت */
function ayahUrl(r,s,a,g){if(r[3])return`https://everyayah.com/data/${r[3]}/${pad(s)}${pad(a)}.mp3`;
  if(r[10]&&CDN_IDS.has(r[10]))return`https://cdn.islamic.network/quran/audio/128/${r[10]}/${g}.mp3`;
  if(!WARNED){WARNED=1;toast('هذا القارئ'+(r[5]!='حفص'?' (برواية '+r[5]+')':'')+' يتوفر للسور كاملة فقط؛ تُستخدم تلاوة العفاسي بحفص للآيات المنفردة')}return`https://cdn.islamic.network/quran/audio/128/ar.alafasy/${g}.mp3`}
const hasFull=r=>!!r[2];
/* تشغيل سورة كاملة */
function playFull(s,pl){const r=REC[S.rec];
  if(r[4]&&!r[4].includes(s)){if(r[3]||r[10]){toast('تُشغَّل السورة آية بآية لأن التسجيل الكامل غير متوفر');return playAyah(s,1,0,1,true)}return toast('هذه السورة غير متوفرة بصوت '+r[1]+'، اختر قارئًا آخر')}
  if(!hasFull(r)){playAyah(s,1,0,1,true);return}
  cur={m:'f',s,pl:!!pl,full:true};document.querySelectorAll('.ay.on').forEach(e=>e.classList.remove('on'));showP('🎧 '+nm(s)+' · '+r[1]);
  const u=`https://${r[2]}/${pad(s)}.mp3`;logPos('listen',{s});
  try{caches.match(u).then(m=>m?m.blob():null).then(b=>run(b?URL.createObjectURL(b):u)).catch(()=>run(u))}catch(e){run(u)}}
async function playAyah(s,a,end,rep,full){try{const d=await api('/surah/'+s+'/quran-uthmani'),r=REC[S.rec],g=d.ayahs[a-1].number;
  const pl=cur&&cur.pl&&cur.full,cont=cur&&cur.m=='a'&&cur.s==s&&a==cur.a+1;cur={m:'a',s,a,a0:cont?cur.a0:a,n:end||d.numberOfAyahs,r:rep||1,k:1,full:!!full||(!end),pl:pl&&!!full};
  document.querySelectorAll('.ay.on').forEach(e=>e.classList.remove('on'));const e=$('#a'+a);if(e&&S.cur==s)e.classList.add('on');
  showP('🎧 '+nm(s)+' · آية '+AR(a)+' · '+r[1]);logPos('listen',{s,a});run(ayahUrl(r,s,a,g))}catch(e){toast('تعذّر تشغيل الآية')}}
function logPos(k,v){const p=ls.get('pos',{});p[k]=v;p[k+'_t']=Date.now();ls.set('pos',p)}
/* نهاية المقطع */
function endItem(){const P=ls.get('pl',{items:[],i:-1});
  if(S.rm==1&&cur){if(cur.m=='f')return playFull(cur.s,cur.pl);return playAyah(cur.s,cur.a0,cur.full?0:cur.n,cur.r,cur.full)}
  if(cur&&cur.pl&&P.items.length){let i=P.i+1;if(i>=P.items.length){if(S.rm==2)i=0;else{$('#pp').textContent='▶';return}}P.i=i;ls.set('pl',P);return playFull(P.items[i],true)}
  if(cur&&cur.full&&S.an&&cur.s<114)return playFull(cur.s+1);
  $('#pp').textContent='▶'}
au.onended=()=>{if(cur){logAdd('done',0);if(cur.m=='a'){if(cur.k<cur.r){cur.k++;au.currentTime=0;au.play();return}if(cur.a<cur.n){cur.k=1;playAyah(cur.s,cur.a+1,cur.n,cur.r,cur.full);return}}endItem();return}$('#pp').textContent='▶'};
function pNext(){if(!cur)return;const P=ls.get('pl',{items:[],i:-1});
  if(cur.pl&&P.items.length){P.i=(P.i+1)%P.items.length;ls.set('pl',P);return playFull(P.items[P.i],true)}
  if(cur.m=='a'&&!cur.full)return cur.a<cur.n?playAyah(cur.s,cur.a+1,cur.n,cur.r):toast('آخر آية في المقطع');
  if(cur.m=='a'&&cur.a<S.cnt[cur.s-1])return playAyah(cur.s,cur.a+1,0,1,true);
  if(cur.s<114)playFull(cur.s+1)}
function pPrev(){if(!cur)return;const P=ls.get('pl',{items:[],i:-1});if(au.currentTime>4&&cur.m=='f'){au.currentTime=0;return}
  if(cur.pl&&P.items.length){P.i=(P.i-1+P.items.length)%P.items.length;ls.set('pl',P);return playFull(P.items[P.i],true)}
  if(cur.m=='a')return cur.a>1?playAyah(cur.s,cur.a-1,cur.full?0:cur.n,cur.r,cur.full):toast('أول آية');
  if(cur.s>1)playFull(cur.s-1)}
try{const ms=navigator.mediaSession;ms.setActionHandler('nexttrack',pNext);ms.setActionHandler('previoustrack',pPrev);ms.setActionHandler('seekto',e=>{au.currentTime=e.seekTime})}catch(e){dbg(e)}
/* ---------- قائمة التشغيل ---------- */
const PLP=[['الجزء ٣٠ (النبأ → الناس)',()=>rng(78,114)],['المعوذات والإخلاص',()=>[112,113,114]],['الكهف · يس · الملك',()=>[18,36,67]],['الأكثر قراءةً',()=>[1,2,18,36,55,56,67,112,113,114]],['القرآن كاملًا',()=>rng(1,114)]];
const rng=(a,b)=>Array.from({length:b-a+1},(_,i)=>a+i);
function plAdd(s){const P=ls.get('pl',{items:[],i:-1});P.items.push(s);ls.set('pl',P);toast('أُضيفت «'+nm(s)+'» إلى قائمة التشغيل')}
async function playlist(){await names();enter('more');const P=ls.get('pl',{items:[],i:-1});
  v.innerHTML=head('🎶 قائمة التشغيل')+`<div class="sub">${AR(P.items.length)} سورة · القارئ: ${esc(REC[S.rec][1])}</div>
  <div class="row"><button class="b" onclick="plPlay(0)" ${P.items.length?'':'disabled'}>▶ تشغيل القائمة</button><button class="o" onclick="cycRm()">${['➡️ بدون تكرار','🔂 تكرار','🔁 تكرار القائمة'][S.rm]}</button><button class="o" onclick="recPicker(playlist)">🎙 القارئ</button></div>
  <label class="lb"><input type="checkbox" ${S.an?'checked':''} onchange="S.an=this.checked;ls.set('autonext',S.an)"> الانتقال التلقائي للسورة التالية عند انتهاء السورة</label>
  <div id="pli">${P.items.map((s,i)=>`<div class="sr"><div class="f1" onclick="plPlay(${i})"><div class="t">${i==P.i?'▶ ':''}${AR(i+1)}. ${esc(nm(s))}</div></div><button class="o" onclick="plMv(${i},-1)">▲</button><button class="o" onclick="plMv(${i},1)">▼</button><button class="o" onclick="plRm(${i})">✕</button></div>`).join('')||'<p class="mt">القائمة فارغة، أضف سورًا من الأسفل</p>'}</div>
  <h3>إضافة سريعة</h3><div>${PLP.map((p,i)=>`<span class="chip" onclick="plPre(${i})">${p[0]}</span>`).join('')}</div>
  <label class="lb">إضافة سورة</label><div class="row"><select id="pls">${surahOpts(1)}</select><button class="b" onclick="plAdd(+$('#pls').value);playlist()">＋ أضف</button></div>
  <button class="o w" onclick="ls.set('pl',{items:[],i:-1});playlist()">🗑 تفريغ القائمة</button>`}
function plPre(i){const P=ls.get('pl',{items:[],i:-1});P.items=P.items.concat(PLP[i][1]());ls.set('pl',P);playlist()}
function plPlay(i){const P=ls.get('pl',{items:[],i:-1});if(!P.items.length)return;P.i=i;ls.set('pl',P);playFull(P.items[i],true)}
function plMv(i,d){const P=ls.get('pl',{items:[],i:-1}),j=i+d;if(j<0||j>=P.items.length)return;[P.items[i],P.items[j]]=[P.items[j],P.items[i]];ls.set('pl',P);playlist()}
function plRm(i){const P=ls.get('pl',{items:[],i:-1});P.items.splice(i,1);P.i=-1;ls.set('pl',P);playlist()}
/* تكرار آية أو مجموعة آيات */
async function repeatUI(s,a){await names();const n=S.cnt[s-1];openSheet(`<h3>🔁 تكرار آيات</h3><div class="sub">${esc(nm(s))}</div><div class="row"><div><label class="lb">من</label><input id="rpa" class="in" type="number" min="1" max="${n}" value="${a}"></div><div><label class="lb">إلى</label><input id="rpb" class="in" type="number" min="1" max="${n}" value="${a}"></div><div><label class="lb">مرّات</label><select id="rpn" class="w">${[2,3,5,7,10,20,33,100].map(x=>`<option>${x}</option>`).join('')}</select></div></div><button class="b w" onclick="goRep(${s})">▶ ابدأ التكرار</button>`)}
function goRep(s){const n=S.cnt[s-1],a=+$('#rpa').value,b=Math.min(n,+$('#rpb').value),k=+$('#rpn').value;if(!(a>=1&&b>=a))return toast('تأكد من أرقام الآيات');closeSheet();playAyah(s,a,b,k)}
