/* جنة القرآن v8 — الرواية (حفص/ورش)، القراءة مع الترجمة، خطة الختمة، إعدادات الآذان، وضع المالك، إشعار التحديث */
'use strict';
/* ---------- الرواية ---------- */
S.riw=ls.get('riw','hafs');S.wed=null;
async function warshEd(){const c=await dbGet('warsh:ed');if(c&&Date.now()-c.t<6048e5)return c.id;
  try{const j=await getJ(API+'/edition/language/ar'),l=(j.data||[]).filter(e=>e.format==='text'),
    w=l.find(e=>/warsh/i.test(e.identifier))||l.find(e=>/warsh|ورش/i.test((e.name||'')+' '+(e.englishName||'')));
    const id=w?w.identifier:null;await dbSet('warsh:ed',{t:Date.now(),id});return id}
  catch(e){dbg(e,'warshEd');return c?c.id:null}}
if(S.riw=='warsh')warshEd().then(id=>{S.wed=id});
/* نص السورة بالرواية المختارة، مع الرجوع لحفص إن تعذّر نص ورش */
async function surahR(s){if(S.riw=='warsh'&&S.wed){try{return await api('/surah/'+s+'/'+S.wed)}catch(e){dbg(e,'warsh text')}}return api('/surah/'+s+'/quran-uthmani')}
async function applyRiw(x){S.riw=x;ls.set('riw',x);let msg;
  if(x=='warsh'){S.wed=await warshEd();const i=REC.findIndex(r=>r[5]=='ورش');
    if(REC[S.rec]&&REC[S.rec][5]!='ورش'&&i>=0){S.rec=i;ls.set('rec',i)}
    msg=S.wed?'تم تفعيل رواية ورش: النص والتلاوة':'تلاوة ورش مفعّلة. نص ورش غير متوفر من المصدر حاليًا فيُعرض نص حفص'}
  else{S.wed=null;if(REC[S.rec]&&REC[S.rec][5]!='حفص'){const i=recIdx('ar.alafasy');if(i>=0){S.rec=i;ls.set('rec',i)}}msg='تم تفعيل رواية حفص عن عاصم'}
  return msg}
async function setRiw(x){toast(await applyRiw(x));sett()}
/* ---------- قراءة مع الترجمة (آية + ترجمتها) ---------- */
async function parallel(s,ed){s=s||ls.get('last',[1])[0];const U=UL();ed=ed||U.tr[0]||'en.sahih';enter('more');v.innerHTML=head('🌐 قراءة مع الترجمة')+LD;
  try{await names();const[d,t]=await Promise.all([api('/surah/'+s+'/quran-uthmani'),api('/surah/'+s+'/'+ed)]);
    if(U.tr[0]!=ed){U.tr=[ed].concat(U.tr.filter(x=>x!=ed)).slice(0,4);ls.set('ul',U)}
    v.innerHTML=head('🌐 سورة '+nm(s))+`<select class="w" onchange="parallel(${s},this.value)">${TR.map(x=>`<option value="${x[0]}" ${x[0]==ed?'selected':''}>${esc(x[1])}</option>`).join('')}</select>`+
      d.ayahs.map((y,i)=>`<div class="pa" onclick="sheet(${s},${y.numberInSurah})"><div class="qt sm">${esc(clean(s,y.numberInSurah,y.text))} ﴿${AR(y.numberInSurah)}﴾</div><div class="tr" dir="${RTLS.test(ed)?'rtl':'ltr'}">${esc((t.ayahs[i]||{}).text||'')}</div></div>`).join('')+
      `<div class="row">${s<114?`<button class="o" onclick="parallel(${s+1},'${ed}')">◀ التالية</button>`:''}${s>1?`<button class="o" onclick="parallel(${s-1},'${ed}')">السابقة ▶</button>`:''}</div>`;scrollTo(0,0)}
  catch(e){dbg(e,'parallel');fail(()=>parallel(s,ed))}}
/* ---------- خطة الختمة ---------- */
const dayW=n=>AR(n)+' '+(n>=3&&n<=10?'أيام':'يومًا');
const pgSurahName=p=>{try{return nm(pgSurah(p))}catch(e){return''}};
function planCard(){const P=ls.get('plan',null);
  if(!P)return `<div class="card"><b>🎯 ابدأ ختمة</b><div class="sub">اختر المدة ونحسب لك ورد كل يوم</div><div class="seg">${[7,15,30,45,60,90].map(d=>`<button onclick="startPlan(${d})">${dayW(d)}</button>`).join('')}</div><div class="row"><input id="pd" class="in" type="number" min="1" max="365" placeholder="عدد أيام آخر" style="max-width:150px"><button class="o" onclick="startPlan(+$('#pd').value)">ابدأ</button></div></div>`;
  const per=Math.ceil(PAGES/P.days),pc=Math.round(P.done/PAGES*100),left=Math.ceil((PAGES-P.done)/per),el=Math.max(0,dayN(td())-dayN(P.start)),
    target=Math.min(PAGES,per*(el+1)),behind=Math.ceil((per*el-P.done)/per),to=Math.min(PAGES,P.done+per),pp=Math.ceil(per/5);
  const st=P.done>=target?`✅ أنهيت ورد اليوم${P.done>=target+per?' وأنت متقدّم':''}`:behind>0?`⚠️ متأخر ${dayW(behind)} — يمكنك اللحاق بقراءة أكثر`:'📖 ورد اليوم ينتظرك';
  return `<div class="card"><b>🎯 ختمة ${dayW(P.days)}</b>${ring(pc,AR(pc)+'٪')}<div class="sub">${AR(P.done)} / ${AR(PAGES)} صفحة · باقي ${dayW(left)} لختمة</div><div class="sub">${st}</div>
  <div class="sub">وردك: صفحة ${AR(P.done+1)} (${esc(pgSurahName(P.done+1))} · جزء ${AR(juzOf(P.done+1))}) ← ${AR(to)} · نحو ${AR(pp)} صفحات بعد كل صلاة</div>
  <div class="row"><button class="b" onclick="mushaf(${P.done+1})">📖 افتح الورد</button><button class="o" onclick="wirdDone()">✔ أنهيت وردي</button></div>
  <div class="row"><input id="pdn" class="in" type="number" min="0" max="${PAGES}" placeholder="آخر صفحة وصلت إليها" style="max-width:190px"><button class="o" onclick="setPlanDone(+$('#pdn').value)">تحديث</button></div>
  <button class="o w" onclick="pgPrefetch(${P.done+1},${to})">⬇️ حمّل ورد اليوم للقراءة دون إنترنت</button>
  <button class="o w" onclick="if(confirm('إلغاء الخطة الحالية؟')){ls.set('plan',null);prog()}">إلغاء الخطة</button></div>`}
function startPlan(d){d=Math.round(+d);if(!(d>=1&&d<=365))return toast('اكتب عدد أيام بين ١ و٣٦٥');ls.set('plan',{days:d,start:td(),done:0});toast('بدأت ختمة '+dayW(d)+' 🌙');prog()}
function setPlanDone(n){const P=ls.get('plan');if(!P)return;n=Math.round(n);if(!(n>=0&&n<=PAGES))return toast('اكتب رقم صفحة بين ٠ و٦٠٤');
  if(n>=PAGES){P.done=PAGES-1;ls.set('plan',P);return wirdDone()}P.done=n;ls.set('plan',P);toast('تم التحديث ✅');prog()}
/* ---------- الآذان: ملف مخصّص، رابط، مستوى الصوت، فتح قفل الصوت ---------- */
dbGet('adhan:file').then(b=>{if(b)try{ADC.blob=URL.createObjectURL(b)}catch(e){dbg(e)}});
{const SIL='data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=';
 const un=()=>{removeEventListener('pointerdown',un,true);try{ad.muted=true;ad.src=SIL;ad.play().then(()=>{ad.pause();ad.muted=false;ad.removeAttribute('src')}).catch(()=>{ad.muted=false})}catch(e){dbg(e)}};
 addEventListener('pointerdown',un,true)}
function adhanSet(){enter('more');const on=ls.get('adhan',true),url=ls.get('adurl',''),vol=ls.get('advol',1),has=!!ADC.blob,nt=ls.get('adnote',true);
  v.innerHTML=head('🕌 إعدادات الآذان')+`<button class="b w" onclick="togAd();adhanSet()">${on?'🔔 الآذان مفعّل عند كل صلاة':'🔕 الآذان متوقف'}</button>
  <button class="o w" onclick="adNote()">${nt?'🔔 إشعار تذكير عند كل صلاة: مفعّل':'🔕 إشعار التذكير: متوقف'}</button>
  <div class="card"><b>🔊 مستوى الصوت</b><input type="range" min="0.1" max="1" step="0.1" value="${vol}" id="advol" class="w"></div>
  <div class="card"><b>🎵 صوت الآذان</b><div class="sub">${has?'✅ ملف من هاتفك (يعمل دون إنترنت)':'الافتراضي: يُجلب من الإنترنت'}</div>
  <label class="lb">ارفع ملف الآذان (mp3 / m4a / ogg، حتى ١٠ م.ب)</label><input type="file" accept="audio/*" id="adf" class="in"><button class="o w" id="adrm" ${has?'':'hidden'}>🗑 حذف الملف المرفوع</button>
  <label class="lb">أو رابط مباشر (https)</label><input id="adu" class="in" dir="ltr" value="${esc(url)}" placeholder="https://example.com/adhan.mp3"></div>
  <div class="row"><button class="b" onclick="playAdhan('Dhuhr',1)">▶ تجربة الآذان</button><button class="o" onclick="stopAdhan()">⏹ إيقاف الآذان</button></div>
  <button class="o w" onclick="adNoteTest()">🔔 تجربة الإشعار</button>
  <div class="sub">عند حلول وقت الصلاة يصلك إشعار ويُرفع الآذان إن كان التطبيق مفتوحًا. الآذان لا يُوقَف إلا من زر «إيقاف الآذان» داخل التطبيق (أزرار التحكم في شاشة القفل معطّلة أثناء الآذان). المتصفحات لا تسمح بتشغيل الصوت والتطبيق مغلق، لذلك يصلك الإشعار فقط في هذه الحالة.</div>
  <button class="o w" onclick="prayer()">→ رجوع</button>`;
  $('#advol').oninput=e=>{ls.set('advol',+e.target.value);ad.volume=+e.target.value};
  $('#adu').onchange=e=>{const u=e.target.value.trim();if(u&&!/^https:\/\//.test(u))return toast('الرابط لازم يبدأ بـ https://');ls.set('adurl',u);toast('تم الحفظ ✅')};
  $('#adf').onchange=async e=>{const f=e.target.files[0];if(!f)return;if(f.size>10485760)return toast('الملف كبير (الحد ١٠ م.ب)');if(!/^audio\//.test(f.type)&&!/\.(mp3|m4a|ogg|wav|aac)$/i.test(f.name))return toast('اختر ملفًا صوتيًا');
    if(await dbSet('adhan:file',f)){if(ADC.blob)URL.revokeObjectURL(ADC.blob);ADC.blob=URL.createObjectURL(f);toast('تم حفظ الآذان ✅');adhanSet()}else toast('تعذّر الحفظ على الجهاز')};
  $('#adrm').onclick=async()=>{await dbDel('adhan:file');if(ADC.blob)URL.revokeObjectURL(ADC.blob);ADC.blob=null;toast('تم الحذف');adhanSet()}}
function adNote(){const on=!ls.get('adnote',true);ls.set('adnote',on);if(on){try{Notification.requestPermission().then(()=>{syncRemCfg();schedPrayerTriggers()})}catch(e){dbg(e)}}else syncRemCfg();toast(on?'تم تفعيل إشعار الصلاة 🔔':'تم إيقاف إشعار الصلاة');adhanSet()}
async function adNoteTest(){if(typeof Notification=='undefined')return toast('الإشعارات غير مدعومة في هذا المتصفح');
  if(Notification.permission!='granted'){try{await Notification.requestPermission()}catch(e){dbg(e)}}
  const ok=await notify('🕌 حان وقت صلاة (تجربة)','حيّ على الصلاة — افتح التطبيق لإيقاف الآذان','adhan-test','#prayer');toast(ok?'أُرسل إشعار التجربة ✅':'فعّل إذن الإشعارات من إعدادات المتصفح')}
/* ---------- وضع المالك (٧ نقرات على اسم المالك) ---------- */
const isOwner=()=>!!ls.get('owner',false);let _ot=[];
function ownerTap(){const n=Date.now();_ot=_ot.filter(t=>n-t<4000);_ot.push(n);
  if(_ot.length>=7){_ot=[];const on=!isOwner();ls.set('owner',on);toast(on?'🛡 وضع المالك مفعّل: يمكنك إنشاء شهادة تجريبية من «شهاداتي»':'تم إيقاف وضع المالك');if(/شهاداتي/.test(($('#v h2')||{}).textContent||''))certs()}
  else if(_ot.length>=4)toast('… '+AR(7-_ot.length))}
/* ---------- إشعار وجود تحديث ---------- */
if('serviceWorker' in navigator){const had=!!navigator.serviceWorker.controller;
  navigator.serviceWorker.addEventListener('controllerchange',()=>{if(!had||$('#upd'))return;const b=document.createElement('div');b.id='upd';b.textContent='🔄 تحديث جديد جاهز — اضغط لإعادة التحميل';b.onclick=()=>location.reload();document.body.appendChild(b)})}

/* ---------- شريط إيقاف الآذان: الإيقاف من داخل التطبيق فقط ---------- */
let ADN='';
function adBar(on){let b=$('#adbar');if(!on){if(b)b.remove();return}
  if(!b){b=document.createElement('div');b.id='adbar';document.body.appendChild(b)}
  b.innerHTML=`<span>🕌 الآذان يُرفع${ADN?' — صلاة '+esc(ADN):''}</span><button onclick="stopAdhan()">⏹ إيقاف الآذان</button>`}
function adMedia(on){try{const ms=navigator.mediaSession;if(!ms)return;
  if(on){ms.metadata=new MediaMetadata({title:'الآذان'+(ADN?' — صلاة '+ADN:''),artist:'جنة القرآن'});
    ['pause','stop','play','seekbackward','seekforward','previoustrack','nexttrack','seekto'].forEach(a=>{try{ms.setActionHandler(a,()=>{})}catch(e){dbg(e)}})}
  else{['stop','seekbackward','seekforward','previoustrack','nexttrack','seekto'].forEach(a=>{try{ms.setActionHandler(a,null)}catch(e){dbg(e)}});
    try{ms.setActionHandler('play',()=>au.play());ms.setActionHandler('pause',()=>au.pause())}catch(e){dbg(e)}}}catch(e){dbg(e,'adMedia')}}
function stopAdhan(){try{ad.onerror=null;ad.pause();ad.currentTime=0}catch(e){dbg(e)}adBar(false);adMedia(false)}
ad.addEventListener('playing',()=>{if(!ad.src||ad.src.startsWith('data:'))return;adBar(true);adMedia(true)});
['pause','ended'].forEach(ev=>ad.addEventListener(ev,()=>{adBar(false);adMedia(false)}));
