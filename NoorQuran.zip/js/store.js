/* جنة القرآن v8 — طبقة التخزين: سجل الأخطاء، localStorage الآمن، IndexedDB للبيانات الكبيرة */
'use strict';
/* ---------- سجل الأخطاء (بدل catch فارغة) ---------- */
const DBG=[];
function dbg(e,w){try{const m=(w?w+': ':'')+((e&&e.message)||e);DBG.push(new Date().toISOString().slice(11,19)+' '+m);if(DBG.length>60)DBG.shift();console.warn('[jq]',m)}catch(_){/* لا نسجّل خطأ السجل نفسه لتجنّب التكرار اللانهائي */}}
/* ---------- localStorage للإعدادات الصغيرة فقط ---------- */
const LEGACY=/^(q:|c:s$|mq:|pm:)/;
const ls={
  get(k,d){try{const x=localStorage.getItem(k);return x?JSON.parse(x):d}catch(e){dbg(e,'ls.get '+k);return d}},
  set(k,x){
    const put=()=>{localStorage.setItem(k,JSON.stringify(x));if(k==='rec'&&typeof REC!='undefined'&&REC[x])localStorage.setItem('recid',JSON.stringify(REC[x][0]))};
    try{put();return true}catch(e){
      dbg(e,'ls.set '+k);lsEvict();
      try{put();return true}catch(e2){dbg(e2,'ls.set retry '+k);lsWarn(k);return false}
    }}};
/* عند امتلاء التخزين نحذف الكاشات القديمة القابلة لإعادة التحميل فقط، ثم نحاول مرة ثانية */
function lsEvict(){try{const ks=[];for(let i=0;i<localStorage.length;i++){const q=localStorage.key(i);if(LEGACY.test(q))ks.push(q)}ks.forEach(q=>localStorage.removeItem(q))}catch(e){dbg(e,'evict')}}
function lsWarn(k){if(lsWarn.t&&Date.now()-lsWarn.t<20000)return;lsWarn.t=Date.now();
  setTimeout(()=>{try{toast('⚠️ مساحة التخزين ممتلئة ولم يُحفظ «'+k+'». صدّر نسخة احتياطية من «البيانات والتخزين»')}catch(e){dbg(e)}},0)}
/* ---------- IndexedDB: نصوص القرآن، الصفحات، قوائم القرّاء، ملفات المستخدم ---------- */
const IDB=(()=>{let p=null;
  const open=()=>p||(p=new Promise((res,rej)=>{try{const r=indexedDB.open('jannat',1);
    r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('kv'))r.result.createObjectStore('kv')};
    r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);r.onblocked=()=>rej(new Error('idb blocked'))}catch(e){rej(e)}}));
  const run=(m,f)=>open().then(d=>new Promise((res,rej)=>{const t=d.transaction('kv',m),q=f(t.objectStore('kv'));
    t.oncomplete=()=>res(q&&q.result);t.onerror=t.onabort=()=>rej(t.error||new Error('idb tx'))}));
  return{get:k=>run('readonly',s=>s.get(k)),set:(k,v)=>run('readwrite',s=>s.put(v,k)),del:k=>run('readwrite',s=>s.delete(k)),keys:()=>run('readonly',s=>s.getAllKeys())}})();
const dbGet=k=>IDB.get(k).catch(e=>{dbg(e,'idb.get '+k);return undefined});
const dbSet=(k,v)=>IDB.set(k,v).then(()=>true).catch(e=>{dbg(e,'idb.set '+k);return false});
const dbDel=k=>IDB.del(k).then(()=>true).catch(e=>{dbg(e,'idb.del '+k);return false});
const dbKeys=async pre=>{try{return(await IDB.keys()).filter(k=>String(k).startsWith(pre||''))}catch(e){dbg(e,'idb.keys');return[]}};
/* ---------- جلب JSON مع مهلة وإعادة محاولة ---------- */
async function getJ(url,ms){let err;for(let i=0;i<2;i++){const ac=new AbortController(),tm=setTimeout(()=>ac.abort(),ms||20000);
  try{const r=await fetch(url,{signal:ac.signal});if(!r.ok)throw new Error('http '+r.status);const j=await r.json();clearTimeout(tm);return j}
  catch(e){clearTimeout(tm);err=e;if(i==0)await new Promise(r=>setTimeout(r,500))}}throw err}
/* ---------- ترحيل البيانات القديمة من localStorage إلى IndexedDB ---------- */
async function migrateLS(){try{const ks=[];for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(/^(q:\d+|c:s)$/.test(k))ks.push(k)}
  for(const k of ks){let v=null;try{v=JSON.parse(localStorage.getItem(k))}catch(e){dbg(e)}
    const dk=k==='c:s'?'a:/surah':'a:/surah/'+k.slice(2)+'/quran-uthmani';
    if(v&&(await dbSet(dk,v)))localStorage.removeItem(k);else if(!v)localStorage.removeItem(k)}
  localStorage.removeItem('mq:rec')}catch(e){dbg(e,'migrateLS')}}
try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist().catch(()=>{})}catch(e){dbg(e,'persist')}
setTimeout(migrateLS,1500);
