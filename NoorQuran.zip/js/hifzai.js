/* جنة القرآن v6 — مساعد الحفظ (قواعد ذكية دون توليد محتوى ديني) */
'use strict';
const HAI=()=>ls.get('hai',null);
const hset=o=>ls.set('hai',o);
const wc=t=>t.trim().split(/\s+/).length;
async function planOrder(H){const a=Math.min(H.from,H.to),b=Math.max(H.from,H.to),r=[];for(let i=a;i<=b;i++)r.push(i);return H.dir<0?r.reverse():r}
async function nextPortion(H){/* يحسب مقطع اليوم الجديد بعدد كلمات تقريبي */
  const ord=await planOrder(H);let si=ord.indexOf(H.ptr.s);if(si<0)return null;let s=H.ptr.s,a=H.ptr.a,w=0,start=a,end=a;
  const d=await surahD(s);for(let i=a;i<=d.ayahs.length;i++){const c=wc(clean(s,i,d.ayahs[i-1].text));if(w>0&&w+c>H.w*1.25)break;w+=c;end=i;if(w>=H.w)break}
  return{s,a:start,b:end,w,last:end>=d.ayahs.length}}
function haiEnd(H,P){/* تقدّم المؤشر */const ord=H._ord;if(!P.last){H.ptr={s:P.s,a:P.b+1};return false}
  const i=ord.indexOf(P.s);if(i+1>=ord.length)return true;H.ptr={s:ord[i+1],a:1};return false}
async function hifzAI(){await names();enter('more');let H=HAI();
  if(!H){v.innerHTML=head('🧠 مساعد الحفظ')+`<div class="sub">يرتّب لك خطة الحفظ والمراجعة تلقائيًا ويتكيّف مع تقدّمك. لا يولّد تفسيرًا أو أحكامًا.</div>
  <label class="lb">من سورة</label><select id="hf" class="w">${surahOpts(114)}</select><label class="lb">إلى سورة</label><select id="ht" class="w">${surahOpts(78)}</select>
  <label class="lb">اتجاه الحفظ</label><select id="hd" class="w"><option value="-1">تنازليًا (من الناس نحو الأعلى، الأيسر للمبتدئ)</option><option value="1">تصاعديًا (من الفاتحة)</option></select>
  <label class="lb">حفظ جديد يوميًا (بالكلمات تقريبًا)</label><select id="hw" class="w">${[20,40,60,100,150].map(x=>`<option ${x==40?'selected':''}>${x}</option>`).join('')}</select><button class="b w" onclick="haiStart()">ابدأ الخطة</button>`;return}
  H._ord=await planOrder(H);const t=td(),due=H.ch.filter(c=>c.nx<=t).sort((a,b)=>a.lv-b.lv),missed=H.last&&H.last!=t?dayN(t)-dayN(H.last):0,heavy=due.length>12;
  let P=null;if(!H.fin&&!heavy&&H.doneD!=t){try{P=await nextPortion(H)}catch(e){dbg(e)}}
  const pc=H.fin?100:Math.round(H.cnt/Math.max(1,H.tot)*100);
  v.innerHTML=head('🧠 مساعد الحفظ')+`<div class="sub">${esc(nm(H.from))} ← ${esc(nm(H.to))} · الهدف: ${AR(H.w)} كلمة يوميًا</div>
  ${missed>1?`<div class="card"><b>🤍 فاتك ${AR(missed)} أيام، لا بأس</b><div class="sub" style="text-align:right">سنركّز على المراجعة أولًا ثم نكمل.</div></div>`:''}
  ${heavy?`<div class="card"><b>⏳ تراكمت مراجعات (${AR(due.length)})</b><div class="sub" style="text-align:right">أجّلنا الجديد حتى تقلّ المراجعات المستحقة عن ١٣.</div></div>`:''}
  <div class="card"><b>🆕 حفظ اليوم</b>${H.fin?'<div class="sub">🎉 أتممت الخطة كاملة، بارك الله فيك</div>':H.doneD==t?'<div class="sub">✔ أنجزت حفظ اليوم</div>':P?`<div class="qt sm" style="margin:4px 0">${esc(nm(P.s))} · الآيات ${AR(P.a)}–${AR(P.b)} <span class="sub">(~${AR(P.w)} كلمة)</span></div><div class="row"><button class="b" onclick="haiOpen(${P.s},${P.a},${P.b})">🧠 افتح وضع الحفظ</button><button class="o" onclick="haiDone(${P.s},${P.a},${P.b},${P.last})">✔ أتممت حفظه</button></div><div class="sub">صعوبة المقطع:</div><div class="row"><button class="o" onclick="haiDiff(-1)">😮‍💨 صعب</button><button class="o" onclick="haiDiff(0)">👍 مناسب</button><button class="o" onclick="haiDiff(1)">💪 سهل</button></div>`:'<div class="sub">لا مقطع جديد اليوم</div>'}</div>
  <div class="card"><b>🔁 مراجعة اليوم (${AR(due.length)})</b>${due.slice(0,12).map(c=>`<div class="sr"><div class="f1"><div class="t">${esc(nm(c.s))} ${AR(c.a)}–${AR(c.b)}</div><div class="sub" style="text-align:right">مستوى ${AR(c.lv)}</div></div><button class="o" onclick="haiOpen(${c.s},${c.a},${c.b})">🧠</button><button class="b" onclick="haiRev('${c.id}',1)">✔</button><button class="o" onclick="haiRev('${c.id}',0)">✖</button></div>`).join('')||'<div class="sub">لا مراجعات مستحقة 🎉</div>'}</div>
  <div class="card"><b>📈 التقدّم</b><div class="pbar"><i style="width:${pc}%"></i></div><div class="sub">${AR(pc)}٪ · ${AR(H.ch.length)} مقطعًا قيد المراجعة</div></div>
  <div class="row"><button class="b" onclick="hifzQuiz()" ${H.ch.length?'':'disabled'}>🎯 اختبرني</button><button class="o" onclick="if(confirm('إلغاء الخطة؟'))hset(null),hifzAI()">إعادة الإعداد</button></div>`}
function haiStart(){const f=+$('#hf').value,t=+$('#ht').value,d=+$('#hd').value,w=+$('#hw').value,a=Math.min(f,t),b=Math.max(f,t),ord=d<0?b:a;
  S.cnt.slice(a-1,b).reduce((x,y)=>x+y,0);hset({from:f,to:t,dir:d,w,ptr:{s:ord,a:1},ch:[],cnt:0,tot:S.cnt.slice(a-1,b).reduce((x,y)=>x+y,0),last:td()});hifzAI()}
async function haiOpen(s,a,b){await hifz(s);$('#ha').value=a;$('#hb').value=b}
async function haiDone(s,a,b,last){const H=HAI();H._ord=await planOrder(H);const t=td();H.ch.push({id:'c'+Date.now().toString(36),s,a,b,lv:0,nx:addDays(t,1)});H.cnt+=b-a+1;H.fin=haiEnd(H,{s,a,b,last});H.doneD=t;H.last=t;
  if(last){const m=ls.get('mem',{});if(!m[s]){m[s]={d:t,lv:0};ls.set('mem',m)}}delete H._ord;hset(H);logAdd('hf',b-a+1);if(window.checkBadges)checkBadges();toast('بارك الله فيك ✅');hifzAI()}
function haiDiff(k){const H=HAI();H.w=Math.max(15,Math.min(300,Math.round(H.w*(k>0?1.25:k<0?.75:1))));hset(H);toast('الهدف الجديد: '+AR(H.w)+' كلمة يوميًا');hifzAI()}
function haiRev(id,ok){const H=HAI(),c=H.ch.find(x=>x.id==id);if(!c)return;c.lv=ok?Math.min(5,c.lv+1):Math.max(0,c.lv-1);c.nx=addDays(td(),ok?RI[c.lv]:1);H.last=td();delete H._ord;hset(H);hifzAI()}
/* اختبرني: يُعرض أول الآية ويُطلب إكمالها */
async function hifzQuiz(){await names();enter('more');const H=HAI();if(!H||!H.ch.length)return hifzAI();const due=H.ch.filter(c=>c.nx<=td()),pool=due.length?due:H.ch,c=pool[Math.floor(Math.random()*pool.length)],a=c.a+Math.floor(Math.random()*(c.b-c.a+1)),t=await ayahT(c.s,a),w=t.split(' '),k=Math.max(2,Math.ceil(w.length/3));
  v.innerHTML=head('🎯 اختبرني')+`<div class="sub">${esc(nm(c.s))} · الآية ${AR(a)}</div><div class="card"><div class="qt">${esc(w.slice(0,k).join(' '))} <span id="qm" class="hid">${esc(w.slice(k).join(' '))}</span></div></div><div class="sub">أكمل الآية بصوتك ثم اكشف الجواب</div><button class="b w" onclick="$('#qm').classList.remove('hid');$('#qr').hidden=false">👁 اكشف</button><div id="qr" hidden><div class="row"><button class="b" onclick="haiRev('${c.id}',1);hifzQuiz()">✔ أحسنت</button><button class="o" onclick="haiRev('${c.id}',0);hifzQuiz()">✖ أخطأت</button></div></div><button class="o w" onclick="hifzAI()">→ الخطة</button>`}
