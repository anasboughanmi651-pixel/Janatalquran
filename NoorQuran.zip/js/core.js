/* جنة القرآن v6 — النواة المشتركة */
'use strict';
const NAV=document.querySelectorAll('#nav button');
function enter(tab){tab=tab||'more';clearInterval(S.iv);try{stopCmp()}catch(e){dbg(e)}S.tab=tab;NAV.forEach(b=>b.classList.toggle('on',b.dataset.t==tab));closeSheet();
  if(!S.inReader){try{history.pushState({r:1},'')}catch(e){dbg(e)}S.inReader=true}scrollTo(0,0)}
function head(t){return `<button class="o bk0" onclick="backBtn()" aria-label="رجوع">${typeof IC!="undefined"?IC.chev:"→"}<span>رجوع</span></button><h2>${t}</h2>`}
const KEYREC=(s,a)=>s+':'+a;
const KP=k=>k.split(':').map(Number);
/* رقم الآية الكلي */
function offs(){if(!S._off){let o=[0];S.cnt.forEach((c,i)=>o.push(o[i]+c));S._off=o}return S._off}
const gidx=(s,a)=>offs()[s-1]+a;
async function surahD(s){await names();return api('/surah/'+s+'/quran-uthmani')}
async function ayahT(s,a){const d=await surahD(s);return clean(s,a,d.ayahs[a-1].text)}
const snip=(t,n)=>t.length>n?t.slice(0,n)+'…':t;
function openSheet(html){const el=$('#sheet');el.hidden=false;el.innerHTML=`<div class="bk" onclick="closeSheet()"></div><div class="sh">${html}</div>`}
const dayN=d=>Math.floor(new Date(d+'T12:00:00Z').getTime()/864e5);
const addDays=(d,n)=>new Date(new Date(d+'T12:00:00Z').getTime()+n*864e5).toISOString().slice(0,10);
function surahOpts(sel){return S.names.map((_,i)=>`<option value="${i+1}" ${i+1==sel?'selected':''}>${AR(i+1)}. ${esc(nm(i+1))}</option>`).join('')}
function dl(name,blob){const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),4000)}
async function shareBlob(name,blob,text){try{const f=new File([blob],name,{type:blob.type});if(navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f],text:text||'جنة القرآن'});return}}catch(e){if(e&&e.name=='AbortError')return}dl(name,blob)}
/* سجل النشاط */
const TODAY=()=>td();
function logAdd(k,n){const L=ls.get('log',{}),d=TODAY();(L[d]=L[d]||{})[k]=(L[d][k]||0)+(n||1);ls.set('log',L)}
/* الإشعارات */
async function notify(title,body,tag,hash){try{if(typeof Notification=='undefined'||Notification.permission!='granted')return false;
  const reg=navigator.serviceWorker&&await navigator.serviceWorker.getRegistration();const o={body,tag:tag||'nq',icon:'icon-192.png',badge:'icon-192.png',data:{hash:hash||''},lang:'ar',dir:'rtl'};
  if(reg&&reg.showNotification)await reg.showNotification(title,o);else new Notification(title,o);return true}catch(e){return false}}
