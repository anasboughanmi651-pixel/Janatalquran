/* جنة القرآن v6 — وضع الخشوع، استوديو الآيات، النسخ الاحتياطي، التخزين، القائمة والتنقل */
'use strict';
/* ---------- وضع الخشوع ---------- */
document.body.insertAdjacentHTML('beforeend','<div id="xk"><button onclick="khushoo(0)">✕ خروج</button><button id="xa" onclick="autoScr()">⏬ تمرير</button></div>');
let WL=null,AS=0,ASR=0;
async function khushoo(on){document.body.classList.toggle('khushoo',!!on);try{if(on){WL=await navigator.wakeLock.request('screen')}else{AS=0;if(WL)WL.release();WL=null}}catch(e){dbg(e)}if(on)toast('وضع الخشوع — اضغط «خروج» للعودة')}
function autoScr(){AS=(AS+1)%4;$('#xa').textContent=AS?'⏬ '+AR(AS)+'×':'⏬ تمرير';cancelAnimationFrame(ASR);if(!AS)return;let acc=0;const f=()=>{if(!AS)return;acc+=AS*.5;if(acc>=1){scrollBy(0,Math.floor(acc));acc%=1}ASR=requestAnimationFrame(f)};f()}
addEventListener('keydown',e=>{if(e.key=='Escape')khushoo(0)});
/* ---------- استوديو الآيات ---------- */
const TPL=[['ذهبي ليلي',['#0b1230','#1b2a63'],'#f6ecd0','#f0c96b','#b08d3b'],['ورقي',['#fffdf5','#f3e6bd'],'#2b2210','#185e46','#b08d3b'],['زمردي',['#0d3d2e','#185e46'],'#f4f0dc','#f0c96b','#e3d3a0'],['غروب',['#3a1c4a','#c2603a'],'#fff6e5','#ffd98a','#ffd98a'],['أسود بسيط',['#000','#111'],'#fff','#aaa','#666'],['فجر',['#14304f','#5a8fb5'],'#fdfdfb','#ffe29a','#cde4f5']];
const AR_=[['مربع',1080,1080],['ستوري',1080,1920],['أفقي',1600,900]];
async function studio(s,a){await names();enter('more');s=s||ls.get('last',[1])[0];a=a||1;const n=S.cnt[s-1];
  v.innerHTML=head('🎨 استوديو الآيات')+`<div class="row"><select id="ss" onchange="studio(+this.value,1)">${surahOpts(s)}</select></div><div class="row"><div><label class="lb">من آية</label><input id="sa" class="in" type="number" min="1" max="${n}" value="${a}"></div><div><label class="lb">إلى آية</label><input id="sb" class="in" type="number" min="1" max="${n}" value="${a}"></div></div>
  <label class="lb">القالب</label><div id="stp">${TPL.map((t,i)=>`<span class="chip ${i==0?'on':''}" data-i="${i}">${t[0]}</span>`).join('')}</div><label class="lb">المقاس</label><div id="sar">${AR_.map((t,i)=>`<span class="chip ${i==0?'on':''}" data-i="${i}">${t[0]}</span>`).join('')}</div>
  <label class="lb"><input type="checkbox" id="sn" checked> إظهار رقم الآية واسم السورة</label><label class="lb">ترجمة أسفل الآية (اختياري)</label><select id="str" class="w"><option value="">بدون</option>${TR.map(x=>`<option value="${x[0]}">${x[1]}</option>`).join('')}</select><label class="lb">خلفية من صورتك (اختياري)</label><input type="file" id="sbg" accept="image/*" class="in">
  <div id="scv"></div><div class="row"><button class="b" id="ssh">↗️ مشاركة</button><button class="o" id="sdl">⬇️ حفظ</button></div>`;
  let ti=0,ai=0,bg=null;const draw=async()=>{const A=Math.min(+$('#sa').value||1,n),B=Math.min(Math.max(A,+$('#sb').value||A),A+7,n);let tx=[];for(let i=A;i<=B;i++)tx.push(await ayahT(s,i)+' ﴿'+AR(i)+'﴾');let tr='';const te=$('#str').value;if(te){try{tr=(await Promise.all(Array.from({length:B-A+1},(_,i)=>api('/ayah/'+gidx(s,A+i)+'/'+te).then(d=>d.text)))).join(' ')}catch(e){dbg(e)}}
    const cv=await studioCanvas(tx.join(' '),nm(s)+' · '+(A==B?AR(A):AR(A)+'–'+AR(B)),TPL[ti],AR_[ai],bg,$('#sn').checked,tr);cv.className='cert';$('#scv').innerHTML='';$('#scv').appendChild(cv);S._sc=cv};
  document.querySelectorAll('#stp .chip').forEach(c=>c.onclick=()=>{ti=+c.dataset.i;document.querySelectorAll('#stp .chip').forEach(x=>x.classList.toggle('on',x==c));draw()});
  document.querySelectorAll('#sar .chip').forEach(c=>c.onclick=()=>{ai=+c.dataset.i;document.querySelectorAll('#sar .chip').forEach(x=>x.classList.toggle('on',x==c));draw()});
  ['sa','sb','sn','str'].forEach(i=>$('#'+i).onchange=draw);$('#sbg').onchange=e=>{const f=e.target.files[0];if(!f)return;const im=new Image();im.onload=()=>{bg=im;draw()};im.src=URL.createObjectURL(f)};
  const bl=()=>new Promise(r=>S._sc.toBlob(r,'image/png'));$('#ssh').onclick=async()=>shareBlob('ayah.png',await bl(),'جنة القرآن');$('#sdl').onclick=async()=>dl('ayah.png',await bl());draw()}
async function studioCanvas(text,title,T,Z,bg,showN,tr){try{await document.fonts.load('54px Amiri');await document.fonts.load('30px Cairo')}catch(e){dbg(e)}
  const W=Z[1],H0=Z[2],c=document.createElement('canvas');c.width=W;c.height=H0;let x=c.getContext('2d');const words=text.split(' '),fs=Math.round(W*(text.length>260?.04:text.length>120?.05:.06));x.font=fs+'px Amiri';
  const wrap=(t,f,mw)=>{x.font=f;const o=[];let l='';t.split(' ').forEach(w=>{const q=l?l+' '+w:w;if(x.measureText(q).width>mw&&l){o.push(l);l=w}else l=q});o.push(l);return o};
  const lines=wrap(text,fs+'px Amiri',W-220),lh=fs*1.9,tl=tr?wrap(tr,Math.round(fs*.4)+'px Cairo',W-260):[],tlh=fs*.7,need=lines.length*lh+(tl.length?tl.length*tlh+80:0)+360,H=Math.max(H0,Math.ceil(need));c.height=H;x=c.getContext('2d');
  const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,T[1][0]);g.addColorStop(1,T[1][1]);x.fillStyle=g;x.fillRect(0,0,W,H);
  if(bg){const r=Math.max(W/bg.width,H/bg.height),w=bg.width*r,h=bg.height*r;x.drawImage(bg,(W-w)/2,(H-h)/2,w,h);x.fillStyle='rgba(0,0,0,.55)';x.fillRect(0,0,W,H)}
  x.strokeStyle=T[4];x.lineWidth=8;x.strokeRect(30,30,W-60,H-60);x.lineWidth=2;x.strokeRect(50,50,W-100,H-100);x.textAlign='center';x.direction='rtl';
  const tot=lines.length*lh+(tl.length?tl.length*tlh+60:0);let y=(H-tot)/2+fs*.8;if(showN){x.fillStyle=T[3];x.font='46px Amiri';x.fillText(title,W/2,130);y=Math.max(y,230)}
  x.fillStyle=T[2];x.font=fs+'px Amiri';lines.forEach((l,i)=>x.fillText(l,W/2,y+i*lh));y+=lines.length*lh;
  if(tl.length){x.fillStyle=T[3];x.direction='ltr';x.font=Math.round(fs*.4)+'px Cairo';y+=20;tl.forEach((l,i)=>x.fillText(l,W/2,y+i*tlh));x.direction='rtl'}
  x.fillStyle=T[4];x.font='30px Cairo';x.fillText('جنة القرآن · '+OWNER_NAME,W/2,H-80);return c}
/* ---------- نسخ احتياطي وتخزين ---------- */
const CACHEK=/^(q:|c:s|pm:|asma|mq:)/;
function backupData(){const o={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(CACHEK.test(k))continue;o[k]=localStorage.getItem(k)}return{app:'jannat-alquran',v:6,t:new Date().toISOString(),d:o}}
function backupExport(){const b=new Blob([JSON.stringify(backupData())],{type:'application/json'});shareBlob('jannat-alquran-backup-'+td()+'.json',b,'نسخة احتياطية من جنة القرآن')}
function backupImport(inp){const f=inp.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const j=JSON.parse(r.result);if(j.app!='jannat-alquran'||!j.d)throw 0;if(!confirm('سيتم دمج النسخة واستبدال بياناتك الحالية المطابقة. متابعة؟'))return;Object.keys(j.d).forEach(k=>{if(!CACHEK.test(k)&&typeof j.d[k]=='string')try{localStorage.setItem(k,j.d[k])}catch(e){dbg(e)}});toast('تمت الاستعادة ✅');setTimeout(()=>location.reload(),900)}catch(e){toast('ملف غير صالح')}};r.readAsText(f)}
async function dataMgr(){enter('more');let est='',au_=0,pg_=0,per=false;
  try{const e=await navigator.storage.estimate();est=`${(e.usage/1048576).toFixed(1)} م.ب من ${(e.quota/1048576).toFixed(0)} م.ب`}catch(e){dbg(e)}
  try{au_=(await(await caches.open('jq-audio')).keys()).length}catch(e){dbg(e)}
  try{pg_=(await(await caches.open('jq-pages')).keys()).length}catch(e){dbg(e)}
  try{per=await navigator.storage.persisted()}catch(e){dbg(e)}
  const nq=(await dbKeys('a:/surah/')).filter(k=>/quran-uthmani$/.test(k)).length;
  v.innerHTML=head('💾 البيانات والتخزين')+`<div class="card"><b>📦 المساحة المستخدمة</b><div class="sub">${est||'غير متاح'}</div><div class="sub">القرآن للعمل دون إنترنت: ${nq>=114?'محمّل كاملًا ✅':'جزئيًا ('+AR(nq)+' / ١١٤ سورة)'}</div><div class="sub">ملفات صوت: ${AR(au_)} · صفحات مصحف: ${AR(pg_)}</div><div class="sub">حماية التخزين من الحذف التلقائي: ${per?'مفعّلة ✅':'غير مفعّلة'}</div></div>
  <button class="b w" onclick="backupExport()">⬇️ تصدير نسخة احتياطية (المفضلة والتقدّم والإعدادات والمكتبة)</button><label class="lb">استيراد نسخة</label><input type="file" accept="application/json,.json" class="in" onchange="backupImport(this)">
  <button class="o w" onclick="dlQuran().then(()=>dataMgr())">⬇️ تحميل القرآن كاملًا (بدون إنترنت)</button><button class="o w" onclick="dlTaf()">⬇️ تحميل التفسير المختار للعمل دون إنترنت</button>
  <button class="o w" onclick="clrAudio()">🗑 حذف الصوت المحمّل</button><button class="o w" onclick="clrCache()">🧹 مسح ذاكرة النصوص المؤقتة</button>
  <button class="o w" onclick="persist()">🔒 طلب حماية التخزين من الحذف التلقائي</button><button class="o w" onclick="showLog()">📋 سجل الأخطاء (${AR(DBG.length)})</button>`}
function showLog(){openSheet('<h3>📋 سجل الأخطاء</h3><pre dir="ltr" style="white-space:pre-wrap;font-size:12px;text-align:left">'+esc(DBG.join('\n')||'لا توجد أخطاء مسجّلة')+'</pre>')}
async function dlTaf(){toast('جارٍ تحميل التفسير…');try{const e=(UL().taf[0]||S.taf);await api('/quran/'+e);delete mem['/quran/'+e];toast('تم الحفظ للعمل دون إنترنت ✅')}catch(x){toast('تعذّر التحميل')}}
async function clrAudio(){if(!confirm('حذف كل الصوت المحمّل؟'))return;try{await caches.delete('jq-audio')}catch(e){dbg(e)}toast('تم الحذف');dataMgr()}
async function clrCache(){const ks=[];for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(/^(pm:|mq:|q:|c:s)/.test(k))ks.push(k)}ks.forEach(k=>localStorage.removeItem(k));
  for(const k of await dbKeys('a:'))await dbDel(k);await dbDel('mq:v8');await dbDel('warsh:ed');localStorage.removeItem('qdl');Object.keys(mem).forEach(k=>delete mem[k]);toast('تم المسح');dataMgr()}
async function persist(){try{toast(await navigator.storage.persist()?'تمت حماية التخزين ✅':'لم يمنح المتصفح الحماية')}catch(e){toast('غير مدعوم')}}
/* ---------- القائمة والتنقل ---------- */
const MENU=[
['📚 مكتبتي',[['📚 مكتبتي (علامات ومجلدات)','library()'],['📖 وضع التدبّر','tadabbur()'],['🔍 مركز الفهم والتفسير','understand()'],['🗂 موسوعة السور','ency()'],['🎨 استوديو الآيات','studio()'],['🌐 قراءة مع الترجمة','parallel()']]],
['🎧 الاستماع',[['🎶 قائمة التشغيل','playlist()'],['↩️ استكمال آخر استماع','resumeListen()'],['📍 آخر مواضعي','positions()'],['🌙 وضع الخشوع (من أي سورة)','openS(ls.get(\'last\',[1,1])[0],ls.get(\'last\',[1,1])[1]).then(()=>khushoo(1))']]],
['🧠 الحفظ والإنجاز',[['🧠 مساعد الحفظ الذكي','hifzAI()'],['🧠 وضع الحفظ والمراجعة','hifz()'],['📊 تحليلات القرآن','analytics()'],['🏅 الإنجازات','badges()'],['🎓 الشهادات','certs()']]],
['🕌 العبادة',[['📄 المصحف الشريف (الصفحات)','mushaf(ls.get(\'pg\',1))'],['🔔 مركز التذكيرات','reminders()'],['🕌 إعدادات الآذان','adhanSet()'],['📿 أذكار مختارة','azkar()'],['✨ أسماء الله الحسنى','asma()'],['📅 التقويم الهجري','cal()'],['🧭 بوصلة القبلة','qibla()'],['📿 المسبحة الإلكترونية','tasbeeh()'],['🎲 آية عشوائية','rnd()'],['❤️ المفضلة',"go('favs')"]]],
['⚙️ التطبيق',[['⚙️ الإعدادات','sett()'],['💾 النسخ الاحتياطي والتخزين','dataMgr()'],['💝 شكر المالك واقتراح فكرة','fb()'],['↗️ شارك التطبيق مع غيرك','shareApp()'],['ℹ️ عن التطبيق','about()']]]];
more=function(){S.tab='more';v.innerHTML=`<h2>المزيد</h2>`+MENU.map(g=>`<h3 style="text-align:right;margin-top:14px">${g[0]}</h3>`+g[1].map(x=>`<button class="card" onclick="${x[1]}">${x[0]}</button>`).join('')).join('')};
const _home=home;home=async function(){await _home();try{if(!$('#sl'))return;const ar=ls.get('ares'),last=ls.get('last');
  const q=document.createElement('div');q.innerHTML=`<div class="grid2" style="margin:8px 0">${ar?`<div class="tile" onclick="resumeListen()"><span>🎧</span>استكمال الاستماع<div class="sub">${esc(nm(ar.s))}</div></div>`:''}<div class="tile" onclick="library()"><span>📚</span>مكتبتي</div><div class="tile" onclick="hifzAI()"><span>🧠</span>مساعد الحفظ</div><div class="tile" onclick="ency()"><span>🗂</span>موسوعة السور</div><div class="tile" onclick="analytics()"><span>📊</span>إنجازاتي <div class="sub">🔥 ${AR(streak().cur)} يوم</div></div><div class="tile" onclick="khushoo(1);openS(ls.get('last',[1,1])[0],ls.get('last',[1,1])[1])"><span>🌙</span>وضع الخشوع</div></div>`;$('#ayd').before(q.firstChild)}catch(e){dbg(e)}};
{const _s=sett;sett=function(){_s();const b=[...v.querySelectorAll('button')].pop();const d=document.createElement('div');d.innerHTML=`<label class="lb"><input type="checkbox" ${S.an?'checked':''} onchange="S.an=this.checked;ls.set('autonext',S.an)"> الانتقال التلقائي للسورة التالية</label><button class="o w" onclick="reminders()">🔔 مركز التذكيرات</button><button class="o w" onclick="playlist()">🎶 قائمة التشغيل</button><button class="o w" onclick="recPicker()">🎙 اختيار القارئ (${AR(REC.length)} قارئًا)</button><button class="o w" onclick="dataMgr()">💾 النسخ الاحتياطي والتخزين</button>`;[...d.childNodes].forEach(n=>v.insertBefore(n,b))}}
/* مسارات الروابط: #library #listen #prayer #azkar #stats #wird #ayah */
function route(){const h=location.hash.replace('#','');if(!h)return;history.replaceState(null,'',location.pathname);({library:()=>library(),listen:()=>resumeListen(),prayer:()=>go('prayer'),azkar:()=>azkar(),stats:()=>analytics(),wird:()=>prog(),ayah:()=>go('home')})[h]?.()}
addEventListener('hashchange',route);setTimeout(route,600);
navigator.serviceWorker&&navigator.serviceWorker.addEventListener('message',e=>{if(e.data&&e.data.hash){location.hash=e.data.hash}});
