/* جنة القرآن v7 — الواجهة الجديدة: أيقونات، تنقل، رئيسية، مصحف، رحلتي، قارئ، مشغّل، ترحيب */
'use strict';
const P=(d,c)=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"${c?` class="${c}"`:''}>${d}</svg>`;
const IC={
home:P('<path d="M4 11l8-7 8 7v8.5a.5.5 0 0 1-.5.5H15v-6H9v6H4.5a.5.5 0 0 1-.5-.5z"/>'),
quran:P('<path d="M4 5.5C4 4.7 4.7 4 5.5 4H11v15H5.5C4.7 19 4 18.3 4 17.5z"/><path d="M20 5.5c0-.8-.7-1.5-1.5-1.5H13v15h5.5c.8 0 1.5-.7 1.5-1.5z"/>'),
listen:P('<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/>'),
mine:P('<path d="M7 4h10v16l-5-3.6L7 20z"/>'),
more:P('<rect x="4" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.5"/>'),
search:P('<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>'),
clock:P('<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>'),
compass:P('<circle cx="12" cy="12" r="8.5"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>'),
beads:P('<circle cx="12" cy="12" r="8"/><circle cx="12" cy="4" r="1.2"/><circle cx="19" cy="8" r="1.2"/><circle cx="19" cy="16" r="1.2"/><circle cx="12" cy="20" r="1.2"/><circle cx="5" cy="16" r="1.2"/><circle cx="5" cy="8" r="1.2"/>'),
star:P('<path d="M12 2.5l2.1 3.2 3.8-.4.4 3.8 3.2 2.1-3.2 2.1-.4 3.8-3.8-.4L12 21.5l-2.1-3.2-3.8.4-.4-3.8L2.5 12.8l3.2-2.1-.4-3.8 3.8.4z"/>'),
flame:P('<path d="M12 3c1 3.5 5 5.5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 1.5 1 2.2 1.8 2.2C11 8 11 5 12 3z"/>'),
mic:P('<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21"/>'),
gear:P('<circle cx="12" cy="12" r="3"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M18.4 5.6l-1.8 1.8M7.4 16.6l-1.8 1.8"/>'),
chev:P('<path d="M9 5l7 7-7 7"/>'),
x:P('<path d="M6 6l12 12M18 6L6 18"/>'),
play:P('<path d="M8 5.5v13l11-6.5z"/>','f'),pause:P('<rect x="6.5" y="5" width="4" height="14" rx="1"/><rect x="13.5" y="5" width="4" height="14" rx="1"/>','f'),
next:P('<path d="M6 6v12l9-6z"/><rect x="16" y="6" width="2.4" height="12" rx="1"/>','f'),prev:P('<path d="M18 6v12l-9-6z"/><rect x="5.6" y="6" width="2.4" height="12" rx="1"/>','f'),
rep:P('<path d="M17 3l3 3-3 3M4 11V9.5A3.5 3.5 0 0 1 7.5 6H20M7 21l-3-3 3-3M20 13v1.5a3.5 3.5 0 0 1-3.5 3.5H4"/>'),
up:P('<path d="M6 15l6-6 6 6"/>'),
chart:P('<path d="M4 20V10M10 20V4M16 20v-7M21 20H3"/>'),
bell:P('<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15zM10 20.5a2 2 0 0 0 4 0"/>'),
cal:P('<rect x="4" y="5.5" width="16" height="14.5" rx="2"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/>'),
heart:P('<path d="M12 20s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7.2a4.3 4.3 0 0 1 7.5 2.6C19.5 15.4 12 20 12 20z"/>'),
share:P('<path d="M12 15V4M8 8l4-4 4 4M5 13v6h14v-6"/>'),
info:P('<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.8v.1"/>'),
note:P('<path d="M6 3.5h9l4 4V20.5H6zM14.5 3.5V8H19M9 12h7M9 15.5h7"/>'),
db:P('<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/>'),
moon:P('<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>'),
sliders:P('<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>'),
list:P('<path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.8" cy="6" r="1"/><circle cx="4.8" cy="12" r="1"/><circle cx="4.8" cy="18" r="1"/>'),
dice:P('<rect x="4" y="4" width="16" height="16" rx="3"/><circle cx="9" cy="9" r="1"/><circle cx="15" cy="15" r="1"/><circle cx="15" cy="9" r="1"/><circle cx="9" cy="15" r="1"/>')};
const MIC={library:'mine',tadabbur:'note',understand:'search',ency:'quran',studio:'star',playlist:'list',resumeListen:'listen',positions:'clock',hifzAI:'star',hifz:'star',analytics:'chart',badges:'star',certs:'note',mushaf:'quran',reminders:'bell',azkar:'beads',asma:'star',cal:'cal',qibla:'compass',tasbeeh:'beads',rnd:'dice',favs:'heart',sett:'gear',dataMgr:'db',fb:'heart',shareApp:'share',about:'info',openS:'moon'};
const mic=a=>IC[MIC[(a.match(/([A-Za-z]+)\(/)||[])[1]]||'star'];
/* ---------- المظهر ---------- */
try{if(localStorage.getItem('night')===null)ls.set('night',false)}catch(e){dbg(e)}
function applyTheme(){const n=ls.get('night',false);document.body.classList.toggle('night',n);document.body.style.setProperty('--fs',ls.get('fs','27')+'px');const m=document.querySelector('meta[name=theme-color]');if(m)m.content=n?'#14110c':'#f1e6c8'}
function togNight(){ls.set('night',!ls.get('night',false));applyTheme();if(S.tab=='more'&&$('#v h2')&&/الإعدادات/.test($('#v h2').textContent))sett()}
applyTheme();document.body.style.fontVariantEmoji='text';
/* رموز تعبيرية بنمط نصّي أحادي اللون */
{const EM=/\p{Extended_Pictographic}/u,G=/(\p{Extended_Pictographic})️?/gu;const fix=n=>{if(n.nodeType==3){if(EM.test(n.nodeValue))n.nodeValue=n.nodeValue.replace(G,'$1︎')}else if(n.nodeType==1&&!/^(SCRIPT|STYLE|TEXTAREA|CANVAS|SVG)$/i.test(n.tagName))n.childNodes.forEach(fix)};
new MutationObserver(ms=>ms.forEach(m=>m.addedNodes.forEach(fix))).observe(document.body,{childList:true,subtree:true});fix(document.body)}
/* ---------- التنقل ---------- */
const TABS=[['home','الرئيسية','home'],['quran','المصحف','quran'],['recite','الاستماع','listen'],['mine','رحلتي','mine'],['more','المزيد','more']];
const NAVMAP={home:'home',prayer:'home',quran:'quran',search:'quran',recite:'recite',mine:'mine',prog:'mine',favs:'mine',more:'more'};
$('#nav').innerHTML=TABS.map(t=>`<button data-t="${t[0]}" aria-label="${t[1]}">${IC[t[2]]}<span>${t[1]}</span></button>`).join('');
const mark=t=>document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.t==(NAVMAP[t]||t)));
document.querySelectorAll('#nav button').forEach(b=>b.onclick=()=>go(b.dataset.t));
enter=function(tab){tab=tab||'more';clearInterval(S.iv);try{stopCmp()}catch(e){dbg(e)}S.tab=tab;mark(tab);closeSheet();if(!S.inReader){try{history.pushState({r:1},'')}catch(e){dbg(e)}S.inReader=true}scrollTo(0,0)};
go=function(t){clearInterval(S.iv);stopCmp();S.tab=t;mark(t);closeSheet();S.inReader=false;try{khushoo(0)}catch(e){dbg(e)}({home,quran,search:srch,recite,mine,prog,prayer,favs:favsV,more})[t]();scrollTo(0,0)};
/* ---------- الرئيسية ---------- */
const greet=()=>{const h=new Date().getHours();return h<5?'ليلة مباركة':h<12?'صباح الخير':h<17?'طاب يومك':'مساء الخير'};
async function home(){S.tab='home';mark('home');v.innerHTML=LD;try{await names()}catch(e){return fail(home)}
  const last=ls.get('last',[1,1]),nm0=ls.get('uname',''),st=streak(),pc=Math.round(seenCnt()/TOT*100),P_=ls.get('plan');
  v.innerHTML=`<div class="hero"><div class="top"><div><div class="gr">${greet()}${nm0?'، '+esc(nm0):''}</div><div class="hj">${hj()}</div><div class="chipw">${IC.flame}<span>${AR(st.cur)} ${st.cur==1?'يوم':'أيام'} متتالية</span></div></div><div class="ic" onclick="sett()" role="button" aria-label="الإعدادات">${IC.gear}</div></div>
  <button class="cont" onclick="openS(${last[0]},${last[1]})"><div><div class="ct">متابعة القراءة</div><div class="cs">سورة ${esc(nm(last[0]))}</div><div class="ct">الآية ${AR(last[1])}</div></div><div class="pl">${IC.play}</div></button></div>
  <div id="hp"></div>
  ${P_?`<div class="card pcard" onclick="prog()"><div class="ring2" style="background:conic-gradient(var(--gold) ${Math.round(P_.done/604*360)}deg,var(--line) 0)"><div>${AR(Math.round(P_.done/604*100))}٪</div></div><div><div class="t">ختمة ${AR(P_.days)} يومًا</div><div class="sub">ورد اليوم: صفحة ${AR(P_.done+1)} ← ${AR(Math.min(604,P_.done+Math.ceil(604/P_.days)))}</div></div></div>`:''}
  <div class="sec"><h4>آية اليوم</h4><a onclick="reminders()">تخصيص</a></div><div id="ayd"></div>
  <div class="sec"><h4>اختصارات</h4></div>
  <div class="qg">${[['استمع','recite','listen'],['حفظ ذكي','hifzAI','star'],['أذكار','azkar','beads'],['القبلة','qibla','compass'],['مسبحة','tasbeeh','beads'],['موسوعة','ency','quran'],['تدبّر','tadabbur','note'],['استوديو','studio','star']].map(q=>`<div class="q" onclick="${q[1]=='recite'?"go('recite')":q[1]+'()'}">${IC[q[2]]}<span>${q[0]}</span></div>`).join('')}</div>
  <div class="sec"><h4>مصحفك</h4><a onclick="go('quran')">كل السور</a></div><div class="card"><div class="sub" style="text-align:right">قرأتَ ${AR(pc)}٪ من آيات القرآن · ${AR(ls.get('khatm',0))} ختمة مكتملة</div><div class="pbar" style="margin-top:8px"><i style="width:${pc}%"></i></div></div>
  <div class="sub" style="margin:18px 0 4px">صُنع بحب · <span onclick="ownerTap()">${OWNER_NAME}</span></div><div id="inst" class="card" hidden onclick="install()" style="margin-top:10px;cursor:pointer">${IC.share} ثبّت «جنة القرآن» على هاتفك</div>`;
  if(DP)$('#inst').hidden=false;else if(/iphone|ipad|ipod/i.test(navigator.userAgent)&&!navigator.standalone){const i=$('#inst');i.hidden=false;i.onclick=()=>toast('اضغط زر المشاركة ثم «إضافة إلى الشاشة الرئيسية»')}homePrayer();dayCard();if(!ls.get('onb'))welcome()}
async function dayCard(){try{const k=await dailyKey(),[s,a]=KP(k),t=await ayahT(s,a),el=$('#ayd');if(!el)return;el.innerHTML=`<div class="card ayc" onclick="openS(${s},${a})"><div class="qt">${esc(t)} <i class="n">﴿${AR(a)}﴾</i></div><div class="ref">سورة ${esc(nm(s))} · ${AR(a)}</div></div><div class="row"><button class="o" onclick="dayRnd().then(dayCard)">${IC.dice.replace('<svg','<svg width="18" height="18"')} آية أخرى</button><button class="o" onclick="playAyah(${s},${a},${a})">${IC.listen.replace('<svg','<svg width="18" height="18"')} استمع</button></div>`}catch(e){dbg(e)}}
daily=dayCard;
async function homePrayer(){const el=$('#hp');if(!el)return;const L=ls.get('loc');
  if(!L){el.innerHTML=`<div class="card pcard" onclick="go('prayer')"><div class="pi">${IC.clock}</div><div><div class="t">مواقيت الصلاة</div><div class="sub">حدّد مدينتك لتظهر الصلاة القادمة والأذان</div></div></div>`;return}
  try{const T=await ptoday(L);const upd=()=>{const el=$('#hp');if(!el){clearInterval(S.iv);return}const n=tzNow(L.tz);let nx=null;for(const p of PR){if(p[0]=='Sunrise')continue;const[h,m]=T[p[0]].split(':'),s=h*3600+m*60;if(s>n.sec){nx=[p,s-n.sec,T[p[0]]];break}}
    if(!nx){const[h,m]=T.Fajr.split(':');nx=[PR[0],86400-n.sec+h*3600+m*60,T.Fajr]}const d=nx[1];
    el.innerHTML=`<div class="card pcard" onclick="go('prayer')"><div class="pi">${IC.clock}</div><div><div class="sub">الصلاة القادمة · ${esc(L.name)}</div><div class="pn">${nx[0][1]} <span class="sub">${nx[2]}</span></div></div><div class="pt">${z2(Math.floor(d/3600))}:${z2(Math.floor(d%3600/60))}:${z2(d%60)}</div></div>`};upd();S.iv=setInterval(upd,1000)}catch(e){el.innerHTML=`<div class="card pcard" onclick="go('prayer')"><div class="pi">${IC.clock}</div><div><div class="t">مواقيت الصلاة</div><div class="sub">اضغط لعرض الأوقات</div></div></div>`}}
/* ---------- المصحف ---------- */
const JZ=[[1,1],[2,142],[2,253],[3,93],[4,24],[4,148],[5,82],[6,111],[7,88],[8,41],[9,93],[11,6],[12,53],[15,1],[17,1],[18,75],[21,1],[23,1],[25,21],[27,56],[29,1],[31,22],[36,28],[39,32],[41,47],[46,1],[51,31],[58,1],[67,1],[78,1]];
async function quran(tab){S.tab='quran';mark('quran');tab=tab||S._qt||'s';S._qt=tab;v.innerHTML=LD;let L;try{await names();L=await api('/surah')}catch(e){return fail(quran)}
  v.innerHTML=`<h2>المصحف الشريف</h2><div style="display:flex;gap:8px;align-items:center"><input id="q" class="in" style="margin:0;flex:1;min-width:0" placeholder="ابحث عن سورة…"><button class="o" style="flex:none;padding:9px 14px" onclick="go('search')" aria-label="بحث في الآيات">${IC.search}</button></div><div class="sub" style="margin-bottom:8px">للبحث في نص الآيات اضغط أيقونة البحث</div>
  <button class="mi" onclick="mushaf(ls.get('pg',1))">${IC.quran}<span>قراءة بالصفحات (٦٠٤ صفحة)</span></button>
  <div class="seg"><button class="${tab=='s'?'on':''}" onclick="quran('s')">السور</button><button class="${tab=='j'?'on':''}" onclick="quran('j')">الأجزاء</button><button class="${tab=='m'?'on':''}" onclick="quran('m')">مكية</button><button class="${tab=='d'?'on':''}" onclick="quran('d')">مدنية</button></div><div id="sl"></div>`;
  const row=x=>`<div class="sr" onclick="openS(${x.number})"><div class="dm"><b>${AR(x.number)}</b></div><div class="f1"><div class="t">${esc(nm(x.number))}</div><div class="sub" style="text-align:right">${x.revelationType=='Meccan'?'مكية':'مدنية'} · ${AR(x.numberOfAyahs)} آية</div></div><div class="en">${esc(x.englishName)}</div></div>`;
  const draw=()=>{const q=$('#q').value.trim(),n=norm(q);if(tab=='j'){$('#sl').innerHTML=JZ.map((j,i)=>`<div class="sr" onclick="openS(${j[0]},${j[1]})"><div class="dm"><b>${AR(i+1)}</b></div><div class="f1"><div class="t">الجزء ${AR(i+1)}</div><div class="sub" style="text-align:right">يبدأ من سورة ${esc(nm(j[0]))} · آية ${AR(j[1])}</div></div></div>`).join('');return}
    const rt=tab=='m'?'Meccan':tab=='d'?'Medinan':'';$('#sl').innerHTML=L.filter(x=>(!rt||x.revelationType==rt)&&(!q||norm(nm(x.number)).includes(n)||x.englishName.toLowerCase().includes(q.toLowerCase())||String(x.number)==q)).map(row).join('')||'<p class="mt">لا نتائج</p>'};
  $('#q').oninput=draw;draw()}
/* ---------- رحلتي ---------- */
async function mine(){S.tab='mine';mark('mine');await names();const st=streak(),T=ls.get('log',{})[td()]||{},pc=Math.round(seenCnt()/TOT*100),P_=ls.get('plan');
  v.innerHTML=`<h2>رحلتي مع القرآن</h2><div class="hub"><div class="stat"><b>${AR(st.cur)}</b><span>يوم متتالٍ</span></div><div class="stat"><b>${AR(T.ay||0)}</b><span>آية اليوم</span></div><div class="stat"><b>${AR(pc)}٪</b><span>من القرآن قرأتَ</span></div><div class="stat"><b>${AR(ls.get('khatm',0))}</b><span>ختمة مكتملة</span></div></div>
  <div class="card pcard" style="margin-top:12px" onclick="prog()">${P_?`<div class="ring2" style="background:conic-gradient(var(--gold) ${Math.round(P_.done/604*360)}deg,var(--line) 0)"><div>${AR(Math.round(P_.done/604*100))}٪</div></div><div><div class="t">ختمة ${AR(P_.days)} يومًا</div><div class="sub">ورد اليوم: صفحة ${AR(P_.done+1)} ←</div></div>`:`<div class="pi">${IC.star}</div><div><div class="t">ابدأ ختمة</div><div class="sub">خطط لختمة في ٣٠ أو ٦٠ يومًا</div></div>`}</div>
  ${[['مكتبتي','library()','mine'],['مساعد الحفظ الذكي','hifzAI()','star'],['وضع التدبّر','tadabbur()','note'],['تحليلاتي وسجل النشاط','analytics()','chart'],['الإنجازات','badges()','star'],['الشهادات','certs()','note'],['آخر مواضعي','positions()','clock'],['قائمة التشغيل','playlist()','list']].map(x=>`<button class="mi" onclick="${x[1]}">${IC[x[2]]}<span>${x[0]}</span></button>`).join('')}`}
/* ---------- المزيد ---------- */
more=function(){S.tab='more';mark('more');v.innerHTML=`<h2>المزيد</h2>`+MENU.map(g=>`<div class="grp">${g[0].replace(/^[^؀-ۿ]+/,'')}</div>`+g[1].map(x=>`<button class="mi" onclick="${x[1]}">${mic(x[1])}<span>${x[0].replace(/^[^؀-ۿ]+/,'')}</span></button>`).join('')).join('')+`<button class="mi" onclick="welcome(1)">${IC.info}<span>جولة تعريفية بالتطبيق</span></button>`};
/* ---------- القارئ ---------- */
const _openS7=openS;
openS=async function(s,a){await _openS7(s,a);try{reader(s)}catch(e){console.error(e)}};
function reader(s){const q=$('.qt');if(!q||v.querySelector('.cart'))return;S.cur=s;const info=(mem['/surah']||ls.get('c:s')||[])[s-1]||{};const bsm=v.querySelector('.bsm');
  [...v.children].forEach(k=>{if(k!==bsm&&k!==q)k.remove()});const mp=document.createElement('div');mp.className='mp';if(bsm)mp.appendChild(bsm);mp.appendChild(q);
  const r=REC[S.rec];v.innerHTML='';
  v.insertAdjacentHTML('beforeend',`<div class="rh"><button class="o bk0" onclick="backBtn()">${IC.chev}<span>رجوع</span></button><button class="o" onclick="sTools(${s})" aria-label="أدوات">${IC.sliders}</button></div><div class="cart"><div class="sn">سورة ${esc(nm(s))}</div><div class="sm">${info.revelationType=='Meccan'?'مكية':'مدنية'} · ${AR(info.numberOfAyahs||S.cnt[s-1])} آية · ترتيبها ${AR(s)}</div></div>
  <div class="tbar"><button class="b" onclick="playFull(${s})">${IC.play.replace('<svg','<svg width="18" height="18"')}<span>استمع</span></button><button class="o" onclick="recPicker()">${IC.mic}<span>${esc(r[1].split(' ').slice(0,2).join(' '))}</span></button><button class="o" onclick="sTools(${s})">${IC.sliders}<span>أدوات</span></button></div>`);
  v.appendChild(mp);v.insertAdjacentHTML('beforeend',`<div class="navr">${s<114?`<button class="o" onclick="openS(${s+1})">${esc(nm(s+1))} ‹</button>`:'<span></span>'}${s>1?`<button class="o" onclick="openS(${s-1})">› ${esc(nm(s-1))}</button>`:'<span></span>'}</div>`);
  if(a0(s))setTimeout(()=>{const e=$('.ay.hl');if(e)e.scrollIntoView({block:'center'})},80);decorate();try{watchReader()}catch(e){dbg(e)}}
const a0=s=>!!document.querySelector('.ay.hl');
function sTools(s){openSheet(`<h3>أدوات السورة</h3>${[['استمع للسورة كاملة',`playFull(${s});closeSheet()`,'listen'],['اختيار القارئ','closeSheet();recPicker()','mic'],['إضافة إلى قائمة التشغيل',`plAdd(${s});closeSheet()`,'list'],['وضع الخشوع',`closeSheet();khushoo(1)`,'moon'],['عن السورة وموضوعاتها',`closeSheet();surahInfo(${s})`,'info'],['مركز الفهم والتفسير',`closeSheet();understand(${s},1)`,'search'],['وضع الحفظ',`closeSheet();hifz(${s})`,'star'],['قراءة مع الترجمة',`closeSheet();parallel(${s})`,'info'],['تحميل الصوت دون إنترنت',`closeSheet();dlAudio(${s})`,'db']].map(x=>`<button class="mi" onclick="${x[1]}">${IC[x[2]]}<span>${x[0]}</span></button>`).join('')}<div class="row"><button class="o" onclick="fsz(-3)">أ−</button><button class="o" onclick="fsz(3)">أ＋</button><button class="o" onclick="togNight()">${ls.get('night',false)?'الوضع الورقي':'الوضع الليلي'}</button></div>`)}
function fsz(d){const n=Math.max(20,Math.min(46,(+ls.get('fs','27'))+d));ls.set('fs',String(n));document.documentElement.style.setProperty('--fs',n+'px');document.body.style.setProperty('--fs',n+'px')}
/* شريط تقدّم القراءة */
document.body.insertAdjacentHTML('beforeend','<div class="rprog"><i></i></div>');
addEventListener('scroll',()=>{const m=$('.mp'),b=$('.rprog i');if(!b)return;if(!m||!S.inReader){b.style.width='0';return}const h=document.documentElement.scrollHeight-innerHeight;b.style.width=(h>0?Math.min(100,scrollY/h*100):0)+'%'},{passive:true});
/* ---------- المشغّل ---------- */
{const pl=$('#player'),sw=(id,svg)=>{const e=$(id);if(e)e.innerHTML=svg};sw('#pv',IC.prev);sw('#pn_',IC.next);
  pl.querySelectorAll('button').forEach(b=>{const o=b.getAttribute('onclick')||'';if(/stopP/.test(o))b.innerHTML=IC.x;else if(/sleepT/.test(o))b.innerHTML=IC.moon;else if(/recPicker/.test(o))b.innerHTML=IC.mic});
  pl.insertAdjacentHTML('afterbegin','');const ex=document.createElement('button');ex.id='pex';ex.innerHTML=IC.up;ex.onclick=()=>pl.classList.toggle('xp');pl.insertBefore(ex,$('#pv'));
  const fixPP=()=>{const p=$('#pp');if(!p)return;const t=p.textContent.trim();if(t=='▶'||t=='▶︎')p.innerHTML=IC.play;else if(t=='⏸'||t=='⏸︎')p.innerHTML=IC.pause};
  new MutationObserver(fixPP).observe($('#pp'),{childList:true});fixPP();
  uiP=function(){$('#psp').textContent=AR(S.spd)+'×';$('#prm').innerHTML=IC.rep+(S.rm==1?'<sup>١</sup>':'');$('#prm').style.opacity=S.rm?1:.55};uiP()}
/* ---------- الترحيب ---------- */
function welcome(again){const old=$('#wl');if(old)old.remove();let riw=S.riw||'hafs';
  const el=document.createElement('div');el.id='wl';document.body.appendChild(el);
  el.innerHTML=`<div class="box"><img class="logo" src="icon-192.png" alt=""><h1>جنة القرآن</h1><div class="sub" style="text-align:center">مصحفك ورفيقك اليومي</div><div class="vs">﴿إِنَّ هَٰذَا الْقُرْآنَ يَهْدِي لِلَّتِي هِيَ أَقْوَمُ﴾</div>
  <label class="lb">اسمك (يظهر في الشهادات)</label><input id="wu" class="in" value="${esc(ls.get('uname',''))}" placeholder="اختياري">
  <label class="lb">الرواية</label><div class="seg" id="wrw"><button data-r="hafs" class="${riw=='hafs'?'on':''}">حفص عن عاصم</button><button data-r="warsh" class="${riw=='warsh'?'on':''}">ورش عن نافع</button></div>
  <label class="lb">مدينتك لمواقيت الصلاة</label><select id="wc" class="w"><option value="">— لاحقًا —</option>${Object.keys(CITIES).map(c=>`<option>${c}</option>`).join('')}</select>
  <label class="lb"><input type="checkbox" id="wp" ${ls.get('plan')?'':'checked'}> ابدأ ختمة في ٣٠ يومًا</label>
  <button class="b w" id="wn">ابدأ الرحلة</button><button class="o w" id="wx">${again?'إغلاق':'تخطّي'}</button></div>`;
  document.querySelectorAll('#wrw button').forEach(b=>b.onclick=()=>{riw=b.dataset.r;document.querySelectorAll('#wrw button').forEach(x=>x.classList.toggle('on',x==b))});
  const fin=async skip=>{if(!skip){const u=$('#wu').value.trim();if(u)ls.set('uname',u);const c=$('#wc').value;if(c){const k=CITIES[c];ls.set('loc',{name:c,lat:k[0],lon:k[1],tz:'Africa/Tunis',method:18})}
      if($('#wp').checked&&!ls.get('plan'))ls.set('plan',{days:30,start:td(),done:0});if(riw!=(S.riw||'hafs'))await applyRiw(riw)}
    ls.set('onb',1);el.remove();if(S.tab=='home')home()};
  $('#wn').onclick=()=>fin(false);$('#wx').onclick=()=>fin(true)}
/* روابط التثبيت للأيفون */
addEventListener('beforeinstallprompt',()=>{});
