/* جنة القرآن — Service Worker (النسخة تُحدَّث تلقائيًا بواسطة tools/build.py) */
const V='noor-e620c467c1',KEEP=[V,'jq-audio','jq-pages'];
const SHELL=['./','index.html','manifest.webmanifest','icon-192.png','icon-512.png','icon-maskable-512.png','hero.jpg','splash-1170x2532.png','v6.css','theme.css','v8.css','apple-touch-icon.png','favicon.png',
 'js/store.js','js/core.js','js/reciters.js','js/audio.js','js/mushaf.js','js/library.js','js/stats.js','js/learn.js','js/hifzai.js','js/surahs.js','js/remind.js','js/extras.js','js/ui.js','js/v8.js'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>Promise.all(SHELL.map(u=>c.add(u).catch(()=>{})))).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>!KEEP.includes(x)).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const r=e.request,u=new URL(r.url);
  if(r.method!=='GET'||r.headers.has('range'))return;
  if(u.origin===location.origin){
    e.respondWith(fetch(r).then(x=>{if(x.ok){const c=x.clone();caches.open(V).then(h=>h.put(r,c))}return x}).catch(()=>caches.match(r).then(m=>m||caches.match('index.html'))));
    return;
  }
  /* صور صفحات المصحف: من الكاش إن حُمّلت مسبقًا، وإلا من الشبكة (لا نخزّن ردودًا opaque) */
  if(u.host==='raw.githubusercontent.com'){e.respondWith(caches.match(r.url).then(m=>m||fetch(r)));return}
  if(/alquran\.cloud|aladhan\.com|fonts\.(googleapis|gstatic)\.com|^(www\.)?mp3quran\.net$/.test(u.host)){
    e.respondWith(caches.match(r).then(m=>{const f=fetch(r).then(x=>{if(x.ok){const c=x.clone();caches.open(V).then(h=>h.put(r,c))}return x}).catch(()=>m);return m&&/alquran\.cloud\/v1\/(quran|surah)\//.test(r.url)?m:f}));
  }
});
self.addEventListener('notificationclick',e=>{e.notification.close();const h=(e.notification.data&&e.notification.data.hash)||'';
  e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{if(cs.length){cs[0].focus();cs[0].postMessage({hash:h});return}return self.clients.openWindow('./'+h)}))});
/* ---------- تذكيرات في الخلفية (المزامنة الدورية، حيث يدعمها المتصفح) ---------- */
function idb(m,k,v){return new Promise(res=>{const r=indexedDB.open('jannat',1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('kv'))r.result.createObjectStore('kv')};
  r.onerror=()=>res(undefined);r.onsuccess=()=>{try{const t=r.result.transaction('kv',m==='get'?'readonly':'readwrite'),s=t.objectStore('kv'),q=m==='get'?s.get(k):s.put(v,k);
    q.onsuccess=()=>res(q.result);q.onerror=()=>res(undefined)}catch(e){res(undefined)}}})}
const tzMin=tz=>{try{const o={};new Intl.DateTimeFormat('en-GB',{timeZone:tz,hour12:false,hour:'2-digit',minute:'2-digit'}).formatToParts(new Date()).forEach(x=>o[x.type]=x.value);return(+o.hour%24)*60+ +o.minute}catch(e){return null}};
const mins=s=>{const[h,m]=String(s).split(':').map(Number);return h*60+m};
async function remCheck(){
  const cfg=await idb('get','rem:cfg');if(!cfg||!cfg.rem)return;
  const cs=await self.clients.matchAll({type:'window',includeUncontrolled:true});if(cs.some(c=>c.visibilityState==='visible'))return; /* التطبيق مفتوح: هو يتولّى التنبيه */
  const now=new Date(),nowM=now.getHours()*60+now.getMinutes(),d=now.toISOString().slice(0,10);
  let F=await idb('get','rem:fired');if(!F||F.d!==d)F={d,ids:[]};
  const R=cfg.rem,fire=async(id,title,body,hash)=>{if(F.ids.includes(id))return;F.ids.push(id);await idb('set','rem:fired',F);
    await self.registration.showNotification(title,{body,tag:'bg-'+id+d,icon:'icon-192.png',data:{hash}})};
  const late=(t,win)=>{const df=nowM-mins(t);return df>=0&&df<=win};
  const pm=(cfg.tz&&tzMin(cfg.tz))??nowM,fresh=cfg.date===d;
  if(R.wird&&R.wird.on&&late(R.wird.t,180)&&!(cfg.wdDone&&cfg.wdDate===d))await fire('wird','📖 وردك اليوم',cfg.wird||'اقرأ وردك من القرآن اليوم','#wird');
  if(R.am&&R.am.on&&late(R.am.t,180))await fire('am','🌅 أذكار الصباح','ابدأ يومك بالذكر','#azkar');
  if(R.pm&&R.pm.on&&late(R.pm.t,180))await fire('pm','🌇 أذكار المساء','اختم يومك بالذكر','#azkar');
  if(R.ayah&&R.ayah.on&&late(R.ayah.t,180))await fire('ayah','⭐ آية اليوم','افتح التطبيق لتقرأ آية اليوم','#ayah');
  const PN={Fajr:'الفجر',Dhuhr:'الظهر',Asr:'العصر',Maghrib:'المغرب',Isha:'العشاء'};
  if(cfg.T&&fresh){
    if(R.pre&&R.pre.on)for(const p in PN){if(!cfg.T[p])continue;const diff=mins(cfg.T[p])-pm;if(diff>0&&diff<=R.pre.m)await fire('pre'+p,'🕌 اقتربت صلاة '+PN[p],'بقي نحو '+diff+' دقائق على أذان '+PN[p],'#prayer')}
    if(cfg.adn!==false)for(const p in PN){if(!cfg.T[p]||(cfg.ab||{})[p]===false)continue;const df=pm-mins(cfg.T[p]);if(df>=0&&df<=20)await fire('adn'+p,'🕌 حان وقت صلاة '+PN[p],'حيّ على الصلاة — افتح التطبيق لتشغيل الآذان وإيقافه','#prayer')}}
}
self.addEventListener('periodicsync',e=>{if(e.tag==='noor-remind')e.waitUntil(remCheck())});
