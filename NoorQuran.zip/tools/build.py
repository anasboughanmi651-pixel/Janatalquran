#!/usr/bin/env python3
"""جنة القرآن — سكربت البناء: يتحقق من الملفات ويحدّث رقم نسخة الـ Service Worker تلقائيًا.
الاستخدام (من مجلد المشروع):  python3 tools/build.py
- يفحص صياغة كل ملفات JS (يتطلب node) ووجود كل الملفات المذكورة في index.html و SHELL
- يحسب بصمة (hash) لمحتوى الملفات ويكتبها في sw.js فيتحدّث التطبيق عند المستخدمين تلقائيًا
"""
import hashlib, os, re, subprocess, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(root)
ok = True
def err(m):
    global ok; ok = False; print('✗', m)
html = open('index.html', encoding='utf-8').read()
refs = re.findall(r'(?:src|href)="((?!https?:|data:|#)[^"]+)"', html)
for r in refs:
    if not os.path.exists(r.split('?')[0]): err('ملف مفقود في index.html: ' + r)
sw = open('sw.js', encoding='utf-8').read()
m = re.search(r"const SHELL=\[(.*?)\];", sw, re.S)
for f in re.findall(r"'([^']+)'", m.group(1)):
    if f != './' and not os.path.exists(f): err('ملف مفقود في SHELL: ' + f)
js = [os.path.join('js', f) for f in sorted(os.listdir('js')) if f.endswith('.js')] + ['sw.js']
for f in js:
    r = subprocess.run(['node', '--check', f], capture_output=True, text=True)
    if r.returncode: err(f + ': ' + r.stderr.strip().splitlines()[0])
if not ok: sys.exit(1)
h = hashlib.sha256()
for dp, dn, fn in os.walk('.'):
    dn[:] = sorted(d for d in dn if d not in ('tools', '.git', 'node_modules'))
    for f in sorted(fn):
        p = os.path.join(dp, f)
        if p in ('./sw.js',) or f.endswith(('.md', '.zip')): continue
        h.update(p.encode()); h.update(open(p, 'rb').read())
ver = h.hexdigest()[:10]
sw = re.sub(r"const V='noor-[^']*'", "const V='noor-%s'" % ver, sw, 1)
open('sw.js', 'w', encoding='utf-8').write(sw)
print('✓ الفحص ناجح — نسخة الـ Service Worker: noor-' + ver)
